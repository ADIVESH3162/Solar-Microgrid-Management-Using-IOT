"""
Synthetic Solar Telemetry Dataset Generator
Simulates realistic, physics-grounded solar microgrid telemetry:
- Diurnal sun trajectory across multiple days
- Atmospheric attenuation and cloud cover fluctuations
- Photovoltaic temperature coefficient derating
- Realistic electrical I-V relationships for small DC solar modules

Generates:
1. data/solar_dataset_sample.csv (24-hour test dataset at 1-minute resolution)
2. data/solar_dataset_historical.csv (7-day historical dataset for ML training)
"""

import math
import random
import sys
from datetime import datetime, timedelta
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import numpy as np
import pandas as pd

from src.config import CSV_COLUMNS, HISTORICAL_CSV_PATH, SAMPLE_CSV_PATH
from src.data_processor import compute_cumulative_energy_wh


def generate_diurnal_dataset(
    start_time: datetime,
    days: int,
    step_minutes: int,
    rated_watts: float = 10.0,
    base_temp_c: float = 27.0,
    data_source_label: str = "SIMULATED_DEMO",
) -> pd.DataFrame:
    """
    Generate synthetic solar records grounded in solar atmospheric geometry.
    """
    records = []
    total_steps = int((days * 24 * 60) / step_minutes)
    current_time = start_time

    # Pre-assign daily weather profiles (cloudiness level per day)
    daily_cloud_base = [random.uniform(0.7, 1.0) for _ in range(days + 1)]
    # Make day 3 a rainy/cloudy day for realistic variability
    if days >= 4:
        daily_cloud_base[2] = 0.35
        daily_cloud_base[3] = 0.65

    for step in range(total_steps):
        day_idx = min(int((step * step_minutes) / (24 * 60)), len(daily_cloud_base) - 1)
        day_cloud_factor = daily_cloud_base[day_idx]

        hour_frac = current_time.hour + current_time.minute / 60.0

        if 6.0 <= hour_frac <= 18.0:
            # Daytime: Sinusoidal elevation
            solar_elev = math.sin((hour_frac - 6.0) / 12.0 * math.pi)

            # Transient cloud ripples
            noise = random.gauss(0, 0.05)
            transient_cloud = max(0.2, min(1.0, day_cloud_factor + noise))

            # Lux calculation (Clear-sky peak ~ 90,000 lx at zenith)
            lux = max(100.0, 90000.0 * (solar_elev ** 1.15) * transient_cloud)
            lux = round(lux + random.gauss(0, 300), 1)

            # Temperature calculation: rises with irradiance
            temp_c = round(base_temp_c + (solar_elev * 8.0 * transient_cloud) + random.gauss(0, 0.4), 1)
            # Humidity: inverse to temperature
            humidity = round(max(25.0, min(95.0, 75.0 - (solar_elev * 32.0 * transient_cloud) + random.gauss(0, 0.8))), 1)

            # PV electrical behavior: Voc ~ 18.5V, Vmp ~ 15.0V
            voltage = round(12.5 + (3.8 * (solar_elev ** 0.5) * transient_cloud) + random.gauss(0, 0.08), 2)

            # Temperature coefficient derating: -0.4% per °C above 25°C
            temp_derate = 1.0 - 0.004 * max(0.0, temp_c - 25.0)
            power_w = round(max(0.0, rated_watts * (lux / 90000.0) * temp_derate), 3)

            # Current: I = P / V
            current_ma = round((power_w / voltage) * 1000.0, 1) if voltage > 0.5 else 0.0
        else:
            # Night time
            lux = round(max(0.0, random.uniform(0.0, 2.0)), 1)
            temp_c = round(base_temp_c - 4.5 + random.gauss(0, 0.3), 1)
            humidity = round(min(98.0, 82.0 + random.gauss(0, 0.6)), 1)
            voltage = 0.0
            current_ma = 0.0
            power_w = 0.0

        records.append({
            "timestamp": current_time.strftime("%Y-%m-%d %H:%M:%S"),
            "temperature_c": temp_c,
            "humidity_pct": humidity,
            "light_lux": lux,
            "solar_voltage_v": voltage,
            "solar_current_ma": current_ma,
            "solar_power_w": power_w,
            "battery_voltage_v": None,
            "battery_current_ma": None,
            "battery_soc_pct": None,
            "load_power_w": 5.0,
            "energy_wh": 0.0,  # Will integrate
            "data_source": data_source_label,
            "sensor_status": "OK",
        })

        current_time += timedelta(minutes=step_minutes)

    df = pd.DataFrame(records)
    # Compute cumulative energy
    df = compute_cumulative_energy_wh(df)
    return df[CSV_COLUMNS]


def main():
    print("Generating synthetic solar datasets for testing and demonstration...")

    # 1. Generate 24-hour sample dataset (1-minute resolution = 1440 records)
    sample_start = datetime(2026, 6, 1, 0, 0, 0)
    df_sample = generate_diurnal_dataset(
        start_time=sample_start,
        days=1,
        step_minutes=1,
        rated_watts=10.0,
        data_source_label="SIMULATED_DEMO",
    )
    SAMPLE_CSV_PATH.parent.mkdir(parents=True, exist_ok=True)
    df_sample.to_csv(SAMPLE_CSV_PATH, index=False)
    print(f"[OK] Created {SAMPLE_CSV_PATH} ({len(df_sample)} records, 24-hour profile)")

    # 2. Generate 7-day historical dataset (5-minute resolution = 2016 records)
    hist_start = datetime(2026, 6, 1, 0, 0, 0)
    df_hist = generate_diurnal_dataset(
        start_time=hist_start,
        days=7,
        step_minutes=5,
        rated_watts=10.0,
        data_source_label="HISTORICAL_ARCHIVE",
    )
    HISTORICAL_CSV_PATH.parent.mkdir(parents=True, exist_ok=True)
    df_hist.to_csv(HISTORICAL_CSV_PATH, index=False)
    print(f"[OK] Created {HISTORICAL_CSV_PATH} ({len(df_hist)} records, 7-day multi-weather archive)")


if __name__ == "__main__":
    main()

