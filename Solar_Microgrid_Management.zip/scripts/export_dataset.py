"""
Dataset Filtering and Export Tool
Enables exporting filtered subsets, daily summaries, or downsampled versions
of microgrid telemetry into the outputs/ directory.
"""

import argparse
import sys
from datetime import datetime
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import pandas as pd

from src.config import HISTORICAL_CSV_PATH, LIVE_CSV_PATH, OUTPUTS_DIR, SAMPLE_CSV_PATH
from src.data_processor import clean_and_prepare_timeseries, compute_daily_summary


def export_data(
    source_type: str = "historical",
    start_date: str = None,
    end_date: str = None,
    aggregate_daily: bool = False,
    output_format: str = "csv",
) -> Path:
    """
    Export processed dataset slice to outputs/ folder.
    """
    if source_type == "live" and LIVE_CSV_PATH.exists():
        src_path = LIVE_CSV_PATH
    elif source_type == "sample" and SAMPLE_CSV_PATH.exists():
        src_path = SAMPLE_CSV_PATH
    else:
        src_path = HISTORICAL_CSV_PATH

    print(f"Reading source data from: {src_path}")
    df = pd.read_csv(src_path)
    df = clean_and_prepare_timeseries(df)

    if start_date:
        df = df[df["timestamp"] >= pd.to_datetime(start_date)]
    if end_date:
        df = df[df["timestamp"] <= pd.to_datetime(end_date)]

    OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
    timestamp_tag = datetime.now().strftime("%Y%m%d_%H%M%S")

    if aggregate_daily:
        export_df = compute_daily_summary(df)
        out_filename = f"solar_daily_summary_{timestamp_tag}.{output_format}"
    else:
        export_df = df
        out_filename = f"solar_export_{source_type}_{timestamp_tag}.{output_format}"

    out_path = OUTPUTS_DIR / out_filename

    if output_format == "csv":
        export_df.to_csv(out_path, index=False)
    elif output_format == "json":
        export_df.to_json(out_path, orient="records", date_format="iso", indent=2)
    else:
        raise ValueError(f"Unsupported format: {output_format}")

    print(f"[OK] Exported {len(export_df)} rows to {out_path}")
    return out_path


def main():
    parser = argparse.ArgumentParser(description="Export and filter Solar Microgrid datasets.")
    parser.add_argument("--source", choices=["historical", "sample", "live"], default="historical")
    parser.add_argument("--start", type=str, default=None, help="Start date (YYYY-MM-DD)")
    parser.add_argument("--end", type=str, default=None, help="End date (YYYY-MM-DD)")
    parser.add_argument("--daily", action="store_true", help="Aggregate into daily summary")
    parser.add_argument("--format", choices=["csv", "json"], default="csv", help="Export format")

    args = parser.parse_args()
    export_data(
        source_type=args.source,
        start_date=args.start,
        end_date=args.end,
        aggregate_daily=args.daily,
        output_format=args.format,
    )


if __name__ == "__main__":
    main()

