"""
AI-Based Solar Microgrid Management System.
Core source package for real-time sensor processing, ML modeling, and microgrid management.
"""

__version__ = "1.0.0"

