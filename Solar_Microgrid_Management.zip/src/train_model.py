"""
Machine Learning Training Module
Trains a Random Forest Regressor to forecast short-term solar power availability.
Enforces chronological train/test splitting and records dataset provenance.
"""

import json
import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional, Tuple

# Ensure project root is on sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from src.config import (
    DEFAULT_MODEL_PATH,
    HISTORICAL_CSV_PATH,
    METRICS_JSON_PATH,
    RANDOM_STATE,
    SAMPLE_CSV_PATH,
    TRAIN_TEST_SPLIT_RATIO,
)
from src.feature_engineering import FEATURE_COLS, prepare_train_test_data

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def train_solar_model(
    data_path: Optional[Path] = None,
    output_model_path: Path = DEFAULT_MODEL_PATH,
    metrics_path: Path = METRICS_JSON_PATH,
    n_estimators: int = 100,
    max_depth: int = 12,
) -> Tuple[RandomForestRegressor, Dict]:
    """
    Train a Random Forest Regressor on solar telemetry dataset.
    """
    # Auto-resolve dataset path
    chosen_path = data_path
    if chosen_path is None or not Path(chosen_path).exists():
        if HISTORICAL_CSV_PATH.exists():
            chosen_path = HISTORICAL_CSV_PATH
        elif SAMPLE_CSV_PATH.exists():
            chosen_path = SAMPLE_CSV_PATH
        else:
            raise FileNotFoundError("Neither historical nor sample dataset found for training.")

    logger.info(f"Loading dataset from: {chosen_path}")
    df = pd.read_csv(chosen_path)

    # Check provenance
    sources = df["data_source"].unique() if "data_source" in df.columns else ["UNKNOWN"]
    is_synthetic = any(str(s).upper() != "LIVE_ESP32" for s in sources)
    if is_synthetic:
        logger.warning(
            "NOTICE: Training dataset contains demonstration/benchmark records (not 100% verified live hardware). "
            "Model predictions and evaluation metrics must be interpreted as proof-of-concept only."
        )

    # Prepare features and chronological splits
    X_train, X_test, y_train, y_test = prepare_train_test_data(df, split_ratio=TRAIN_TEST_SPLIT_RATIO)
    logger.info(f"Dataset split: {len(X_train)} training samples, {len(X_test)} testing samples.")

    # Instantiate model
    model = RandomForestRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        random_state=RANDOM_STATE,
        n_jobs=-1,
    )

    # Train
    logger.info("Fitting Random Forest Regressor...")
    model.fit(X_train, y_train)

    # Evaluate on test set
    y_pred = model.predict(X_test)
    y_pred = np.clip(y_pred, 0.0, None)  # Physical constraint: power cannot be negative

    mae = float(mean_absolute_error(y_test, y_pred))
    mse = float(mean_squared_error(y_test, y_pred))
    rmse = float(np.sqrt(mse))
    r2 = float(r2_score(y_test, y_pred))

    # Feature importance dictionary
    importances = {col: round(float(imp), 4) for col, imp in zip(FEATURE_COLS, model.feature_importances_)}

    metrics = {
        "model_type": "RandomForestRegressor",
        "trained_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "training_records": len(X_train),
        "test_records": len(X_test),
        "mae_w": round(mae, 4),
        "rmse_w": round(rmse, 4),
        "r2_score": round(r2, 4),
        "dataset_source": list(sources),
        "is_synthetic_demonstration": is_synthetic,
        "feature_importances": importances,
    }

    # Save artifacts
    output_model_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, output_model_path)
    logger.info(f"Model saved to {output_model_path}")

    metrics_path.parent.mkdir(parents=True, exist_ok=True)
    with open(metrics_path, "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=4)
    logger.info(f"Model metrics saved to {metrics_path}")

    # Output clear summary
    print("\n" + "=" * 60)
    print("      SOLAR POWER PREDICTION MODEL TRAINING RESULTS")
    print("=" * 60)
    print(f"Model File       : {output_model_path.name}")
    print(f"Dataset Records  : {len(df)} total ({len(X_train)} train, {len(X_test)} test)")
    print(f"MAE              : {mae:.4f} W")
    print(f"RMSE             : {rmse:.4f} W")
    print(f"R² Score         : {r2:.4f}")
    print(f"Synthetic Data?  : {'YES (Demonstration Only)' if is_synthetic else 'NO (Genuine Hardware Data)'}")
    print("Feature Importances:")
    for feat, imp in sorted(importances.items(), key=lambda x: x[1], reverse=True):
        print(f"  - {feat:16s}: {imp:.4f}")
    print("=" * 60 + "\n")

    return model, metrics


if __name__ == "__main__":
    train_solar_model()
