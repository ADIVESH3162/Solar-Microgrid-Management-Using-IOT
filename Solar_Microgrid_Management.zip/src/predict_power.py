"""
Inference and Power Prediction Pipeline
Loads trained Random Forest model and executes short-term solar power forecasting.
"""

import json
import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional, Union

# Ensure project root is on sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import joblib
import numpy as np
import pandas as pd

from src.config import DEFAULT_MODEL_PATH, FEATURE_COLS, METRICS_JSON_PATH
from src.feature_engineering import create_features

logger = logging.getLogger(__name__)


class SolarPowerPredictor:
    """
    Inference manager for solar PV generation forecasting.
    """

    def __init__(self, model_path: Path = DEFAULT_MODEL_PATH, metrics_path: Path = METRICS_JSON_PATH):
        self.model_path = Path(model_path)
        self.metrics_path = Path(metrics_path)
        self.model = None
        self.metadata = {}
        self.is_loaded = False
        self._load_model()

    def _load_model(self):
        """Load serialized Random Forest weights and metadata."""
        if not self.model_path.exists():
            logger.warning(f"No trained model found at {self.model_path}. Prediction unavailable until trained.")
            return

        try:
            self.model = joblib.load(self.model_path)
            self.is_loaded = True
            logger.info(f"Loaded trained solar regression model from {self.model_path}")
        except Exception as ex:
            logger.error(f"Failed to load model file: {ex}")
            self.is_loaded = False

        if self.metrics_path.exists():
            try:
                with open(self.metrics_path, "r", encoding="utf-8") as f:
                    self.metadata = json.load(f)
            except Exception as ex:
                logger.warning(f"Could not read metrics JSON: {ex}")

    def predict_from_record(
        self,
        light_lux: float,
        temperature_c: float,
        humidity_pct: float,
        timestamp: Optional[datetime] = None,
        lux_lag_1: Optional[float] = None,
    ) -> Dict[str, Union[float, str, bool]]:
        """
        Execute single-point solar power forecast for current atmospheric conditions.
        """
        if not self.is_loaded or self.model is None:
            return {
                "predicted_power_w": 0.0,
                "confidence_flag": "MODEL_NOT_LOADED",
                "warning": "Model weights have not been trained or loaded.",
            }

        now = timestamp or datetime.now()
        hour = now.hour
        minute = now.minute

        hour_sin = np.sin(2.0 * np.pi * (hour + minute / 60.0) / 24.0)
        hour_cos = np.cos(2.0 * np.pi * (hour + minute / 60.0) / 24.0)

        lag_lux = lux_lag_1 if lux_lag_1 is not None else light_lux

        feature_dict = {
            "light_lux": [light_lux],
            "temperature_c": [temperature_c],
            "humidity_pct": [humidity_pct],
            "hour": [hour],
            "minute": [minute],
            "hour_sin": [hour_sin],
            "hour_cos": [hour_cos],
            "lux_lag_1": [lag_lux],
            "temp_rolling_3": [temperature_c],
            "lux_rolling_3": [light_lux],
        }

        X_input = pd.DataFrame(feature_dict)[FEATURE_COLS]

        # Night physical enforcement
        if light_lux <= 5.0 or hour < 5 or hour > 19:
            pred_power = 0.0
            warning = "Solar power zeroed due to darkness/night hours."
        else:
            raw_pred = float(self.model.predict(X_input)[0])
            pred_power = max(0.0, round(raw_pred, 3))
            warning = "Valid daylight forecast."

        is_synthetic = self.metadata.get("is_synthetic_demonstration", True)

        return {
            "predicted_power_w": pred_power,
            "light_lux": light_lux,
            "temperature_c": temperature_c,
            "confidence_flag": "HIGH" if pred_power > 0 else "ZERO_IRRADIANCE",
            "warning": warning,
            "is_synthetic_demonstration": is_synthetic,
        }

    def predict_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Perform batch predictions over an entire dataframe.
        Appends 'predicted_power_w' column.
        """
        if df.empty or not self.is_loaded or self.model is None:
            result = df.copy()
            result["predicted_power_w"] = 0.0
            return result

        result = df.copy()
        featured = create_features(result, is_training=False)
        X = featured[FEATURE_COLS]

        preds = self.model.predict(X)
        preds = np.clip(preds, 0.0, None)

        # Apply darkness filter
        if "light_lux" in featured.columns:
            dark_mask = featured["light_lux"] <= 5.0
            preds[dark_mask] = 0.0

        result["predicted_power_w"] = np.round(preds, 3)
        return result
