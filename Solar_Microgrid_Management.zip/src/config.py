"""
Global Configuration and System Constants
Central repository for project file paths, electrical specifications,
serial communication defaults, dataset schemas, and anomaly thresholds.
"""

from pathlib import Path

# Base Paths (dynamically anchored to repository root)
SRC_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SRC_DIR.parent

DATA_DIR = PROJECT_ROOT / "data"
MODELS_DIR = PROJECT_ROOT / "models"
OUTPUTS_DIR = PROJECT_ROOT / "outputs"
DOCS_DIR = PROJECT_ROOT / "docs"

# CSV Dataset Paths
SAMPLE_CSV_PATH = DATA_DIR / "solar_dataset_sample.csv"
LIVE_CSV_PATH = DATA_DIR / "solar_dataset_live.csv"
DEMO_CSV_PATH = DATA_DIR / "solar_dataset_demo.csv"
HISTORICAL_CSV_PATH = DATA_DIR / "solar_dataset_historical.csv"

# Machine Learning Model Path
DEFAULT_MODEL_PATH = MODELS_DIR / "solar_power_rf_model.joblib"
METRICS_JSON_PATH = MODELS_DIR / "model_metrics.json"

# Canonical Live Hardware CSV Schema (Strict 9-Column Specification)
LIVE_CSV_COLUMNS = [
    "timestamp",
    "temperature_c",
    "humidity_pct",
    "light_lux",
    "solar_voltage_v",
    "solar_current_ma",
    "solar_power_w",
    "data_source",
    "sensor_status",
]

CSV_COLUMNS = LIVE_CSV_COLUMNS

# Simulation Demo CSV Schema (8 Columns)
DEMO_CSV_COLUMNS = [
    "timestamp",
    "temperature_c",
    "humidity_pct",
    "light_lux",
    "solar_voltage_v",
    "solar_current_ma",
    "solar_power_w",
    "data_source",
]

# Hardware & Simulation Data Source Constants
DATA_SOURCE_HARDWARE = "esp32_hardware"
DATA_SOURCE_LIVE = "esp32_hardware"
DATA_SOURCE_DEMO = "simulation_demo"
DATA_SOURCE_SIMULATION_DEMO = "simulation_demo"
DEFAULT_SIMULATION_INTERVAL_SEC = 2.0

# Serial Port Defaults
DEFAULT_BAUD_RATE = 115200
DEFAULT_TIMEOUT_SEC = 2.0
ESP32_CHIP_IDENTIFIERS = ["CP210", "CH340", "USB-SERIAL", "CH9102", "FTDI", "Silicon Labs"]

# Microgrid Electrical Defaults and Safety Boundaries
DEFAULT_LOAD_POWER_W = 5.0  # Configurable DC load power target
MAX_SAFE_VOLTAGE_V = 25.0    # Absolute max rating for small DC solar bench setup
MAX_SAFE_CURRENT_MA = 3000.0 # Absolute max continuous current through INA219 shunt
MAX_SAFE_TEMPERATURE_C = 65.0
MIN_SAFE_TEMPERATURE_C = -10.0

# 18650 Battery Voltage Profile (Nominal 3.7V Single Cell)
BATTERY_CUTOFF_V = 3.0       # Minimum safe discharge cut-off
BATTERY_NOMINAL_V = 3.7
BATTERY_FULL_V = 4.2         # Maximum safe charge termination

# Machine Learning Configuration
RANDOM_STATE = 42
TRAIN_TEST_SPLIT_RATIO = 0.8  # 80% Train, 20% Test (chronological split)
FEATURE_COLS = [
    "light_lux",
    "temperature_c",
    "humidity_pct",
    "hour",
    "minute",
    "hour_sin",
    "hour_cos",
    "lux_lag_1",
    "temp_rolling_3",
    "lux_rolling_3",
]
TARGET_COL = "solar_power_w"

