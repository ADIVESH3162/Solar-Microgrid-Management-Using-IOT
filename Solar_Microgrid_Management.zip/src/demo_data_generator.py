"""
Continuously Changing Real-Time Demo Data Simulator
Generates physics-guided, smoothly fluctuating simulated solar microgrid telemetry
at configurable intervals (1s, 2s, 5s, 10s) for demonstrations and testing.
Saves records strictly to data/solar_dataset_demo.csv with data_source='simulation_demo'.
"""

import logging
import random
import sys
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

# Ensure project root is on sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import pandas as pd

from src.config import DATA_SOURCE_SIMULATION_DEMO, DEMO_CSV_COLUMNS

logger = logging.getLogger(__name__)


class DemoDataGenerator:
    """
    Stateful real-time simulator that generates realistic, smoothly changing
    sensor readings (Temperature, Humidity, Lux, Voltage, Current, Power) at a
    configurable interval.
    
    Uses gentle random walk perturbations rather than jumping wildly, simulating
    sunlight transients and thermal inertia.
    Power is consistently computed as Power (W) = Voltage (V) * (Current (mA) / 1000.0).
    """

    def __init__(
        self,
        interval_sec: float = 2.0,
        base_temp_c: float = 29.5,
        base_humidity_pct: float = 54.0,
        base_lux: float = 55000.0,
        base_voltage_v: float = 15.2,
    ):
        self.interval_sec = float(interval_sec)
        self.is_running = True
        self.last_step_time = 0.0
        self.latest_reading: Optional[Dict[str, Any]] = None
        self.history: List[Dict[str, Any]] = []

        # Smooth state variables
        self.curr_temp = float(base_temp_c)
        self.curr_humidity = float(base_humidity_pct)
        self.curr_lux = float(base_lux)
        self.curr_voltage = float(base_voltage_v)
        self.cloud_factor = 1.0
        self.step_count = 0

        # Threading and synchronization
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._worker_thread: Optional[threading.Thread] = None
        self.csv_logger: Optional[Any] = None

    def set_interval(self, interval_sec: float):
        """Update telemetry emission interval in seconds."""
        with self._lock:
            self.interval_sec = max(0.5, float(interval_sec))
            logger.info(f"Demo generator interval set to {self.interval_sec}s")

    def start(self, csv_logger: Optional[Any] = None):
        """Start the background generation thread."""
        with self._lock:
            if self.is_running:
                return
            self.is_running = True
            self.csv_logger = csv_logger
            self._stop_event.clear()

            self._worker_thread = threading.Thread(
                target=self._worker_loop,
                name="DemoDataGeneratorWorker",
                daemon=True,
            )
            self._worker_thread.start()
            logger.info("DemoDataGenerator background thread started")

    def stop(self):
        """Stop the background generation thread."""
        with self._lock:
            self.is_running = False
            self._stop_event.set()

        if self._worker_thread and self._worker_thread.is_alive():
            self._worker_thread.join(timeout=1.0)
        self._worker_thread = None
        logger.info("DemoDataGenerator background thread stopped")

    def _worker_loop(self):
        """Background thread worker that generates readings at the configured interval."""
        while not self._stop_event.is_set() and self.is_running:
            self.step(csv_logger=self.csv_logger, force=True)
            # Sleep in small increments for responsive stop requests
            sleep_slices = max(1, int(self.interval_sec / 0.1))
            for _ in range(sleep_slices):
                if self._stop_event.is_set() or not self.is_running:
                    break
                time.sleep(0.1)

    def generate_next_reading(self) -> Dict[str, Any]:
        """
        Produce a single physics-guided reading with smooth transitions.
        Simulates natural irradiance drift, temperature changes, and calculates power.
        """
        self.step_count += 1

        # 1. Smooth Sunlight Variation (Lux)
        # Slow cloud transients every ~15-25 steps
        if random.random() < 0.06:
            self.cloud_factor = random.uniform(0.70, 1.05)
        else:
            # Gentle drift towards nominal cloud factor 1.0
            self.cloud_factor += 0.03 * (1.0 - self.cloud_factor)

        # Gentle lux random walk with mean reversion towards 55,000 lux
        lux_jitter = random.gauss(0, 450)
        lux_drift = 0.02 * (55000.0 * self.cloud_factor - self.curr_lux)
        self.curr_lux = max(12000.0, min(88000.0, self.curr_lux + lux_jitter + lux_drift))
        lux_out = round(self.curr_lux, 1)

        # 2. Ambient Temperature (°C)
        # Thermal inertia: temperature gently tracks sunlight + small Gaussian jitter
        temp_target = 26.0 + (lux_out / 85000.0) * 11.0
        temp_drift = 0.015 * (temp_target - self.curr_temp)
        temp_jitter = random.gauss(0, 0.12)
        self.curr_temp = max(22.0, min(45.0, self.curr_temp + temp_drift + temp_jitter))
        temp_out = round(self.curr_temp, 1)

        # 3. Relative Humidity (%)
        # Inversely correlated with temperature + small jitter
        hum_target = max(30.0, min(80.0, 75.0 - (temp_out - 22.0) * 2.2))
        hum_drift = 0.02 * (hum_target - self.curr_humidity)
        hum_jitter = random.gauss(0, 0.25)
        self.curr_humidity = max(25.0, min(85.0, self.curr_humidity + hum_drift + hum_jitter))
        hum_out = round(self.curr_humidity, 1)

        # 4. Solar Voltage (V)
        # Small PV bench setup operating range ~ 13V - 18V
        v_target = 13.2 + 3.8 * (lux_out / 85000.0)
        v_jitter = random.gauss(0, 0.04)
        self.curr_voltage = max(11.5, min(18.5, self.curr_voltage + 0.05 * (v_target - self.curr_voltage) + v_jitter))
        voltage_out = round(self.curr_voltage, 2)

        # 5. Solar Current (mA)
        # Current is predominantly linear with irradiance
        i_target = max(60.0, (lux_out / 85000.0) * 780.0)
        i_jitter = random.gauss(0, 8.0)
        current_ma = max(50.0, min(1100.0, round(i_target + i_jitter, 1)))

        # 6. Consistent Power Calculation: Power (W) = Voltage (V) * Current (A)
        # Convert mA to A: current_a = current_ma / 1000.0
        current_a = current_ma / 1000.0
        power_w = round(voltage_out * current_a, 3)

        now_dt = datetime.now()
        if hasattr(self, "_last_generated_dt"):
            from datetime import timedelta
            if now_dt <= self._last_generated_dt or now_dt.strftime("%Y-%m-%d %H:%M:%S") == self._last_generated_dt.strftime("%Y-%m-%d %H:%M:%S"):
                now_dt = self._last_generated_dt + timedelta(seconds=1)
        self._last_generated_dt = now_dt
        now_iso = now_dt.strftime("%Y-%m-%d %H:%M:%S")

        return {
            "timestamp": now_iso,
            "temperature_c": temp_out,
            "humidity_pct": hum_out,
            "light_lux": lux_out,
            "solar_voltage_v": voltage_out,
            "solar_current_ma": current_ma,
            "solar_power_w": power_w,
            "data_source": DATA_SOURCE_SIMULATION_DEMO,
        }

    def step(self, csv_logger: Optional[Any] = None, force: bool = False) -> Optional[Dict[str, Any]]:
        """
        Execute a simulation step if interval has elapsed or if forced.
        Appends record to in-memory history and demo CSV logger.
        Returns the new reading, or the latest reading if interval not elapsed.
        """
        if not self.is_running and not force:
            return None

        now = time.time()
        elapsed = now - self.last_step_time

        if not force and elapsed < max(0.1, self.interval_sec - 0.15):
            # Interval has not elapsed yet; return existing latest reading without duplicating
            with self._lock:
                return dict(self.latest_reading) if self.latest_reading else None

        # Generate fresh reading
        reading = self.generate_next_reading()

        with self._lock:
            self.latest_reading = reading
            self.last_step_time = now
            self.history.append(reading)
            # Keep bounded in-memory history (last 2000 points)
            if len(self.history) > 2000:
                self.history.pop(0)

        # Append to demo CSV file if logger provided
        target_logger = csv_logger or self.csv_logger
        if target_logger is not None:
            try:
                target_logger.append_reading(reading)
            except Exception as ex:
                logger.error(f"Error appending demo reading to CSV: {ex}")

        return reading

    def get_latest_reading(self) -> Optional[Dict[str, Any]]:
        """Thread-safe getter for most recent simulated reading."""
        with self._lock:
            return dict(self.latest_reading) if self.latest_reading else None

    def get_history_df(self, max_records: Optional[int] = None) -> pd.DataFrame:
        """Return history as pandas DataFrame."""
        with self._lock:
            if not self.history:
                return pd.DataFrame(columns=DEMO_CSV_COLUMNS)
            records = self.history[-max_records:] if max_records else list(self.history)
            return pd.DataFrame(records)

    def clear_history(self, clear_csv_path: Optional[Path] = None):
        """Clear in-memory session history and optionally truncate demo CSV."""
        with self._lock:
            self.history.clear()
            self.latest_reading = None
            self.last_step_time = 0.0

        if clear_csv_path and Path(clear_csv_path).exists():
            try:
                with open(clear_csv_path, "w", newline="", encoding="utf-8") as f:
                    f.write(",".join(DEMO_CSV_COLUMNS) + "\n")
                logger.info(f"Cleared demo CSV file at {clear_csv_path}")
            except Exception as ex:
                logger.error(f"Failed to clear demo CSV: {ex}")
