"""
Energy Management and Decision Engine Module
Evaluates power balance between solar generation and connected DC loads,
computes power surplus/deficit, evaluates battery storage advisory states,
and generates actionable microgrid dispatch recommendations.
"""

import logging
import sys
from enum import Enum
from pathlib import Path
from typing import Dict, Optional, Union

# Ensure project root is on sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.config import (
    BATTERY_CUTOFF_V,
    BATTERY_FULL_V,
    BATTERY_NOMINAL_V,
    DEFAULT_LOAD_POWER_W,
)

logger = logging.getLogger(__name__)


class MicrogridStatus(str, Enum):
    SOLAR_SUFFICIENT = "SOLAR_SUFFICIENT"
    SOLAR_INSUFFICIENT = "SOLAR_INSUFFICIENT"
    INSUFFICIENT_DATA = "INSUFFICIENT_DATA"


class EnergyManager:
    """
    Microgrid dispatch and advisory decision logic.
    Operates in advisory (software-only) mode until certified power switching hardware is present.
    """

    def __init__(self, load_power_w: float = DEFAULT_LOAD_POWER_W):
        self.load_power_w = load_power_w

    def estimate_battery_soc(self, battery_voltage_v: Optional[float]) -> Optional[float]:
        """
        Estimate 18650 Li-ion battery State-of-Charge (SoC %) from Open-Circuit Voltage (OCV).
        Linear interpolation approximation across typical 18650 discharge curve:
          4.20V -> 100%
          4.00V -> 80%
          3.82V -> 50%
          3.65V -> 20%
          3.00V -> 0%
        """
        if battery_voltage_v is None or battery_voltage_v <= 0:
            return None

        v = float(battery_voltage_v)
        if v >= BATTERY_FULL_V:
            return 100.0
        if v <= BATTERY_CUTOFF_V:
            return 0.0

        if v >= 4.0:
            soc = 80.0 + (v - 4.0) / (4.2 - 4.0) * 20.0
        elif v >= 3.82:
            soc = 50.0 + (v - 3.82) / (4.0 - 3.82) * 30.0
        elif v >= 3.65:
            soc = 20.0 + (v - 3.65) / (3.82 - 3.65) * 30.0
        else:
            soc = (v - 3.0) / (3.65 - 3.0) * 20.0

        return round(float(soc), 1)

    def evaluate_energy_balance(
        self,
        solar_power_w: Optional[float],
        load_power_w: Optional[float] = None,
        battery_voltage_v: Optional[float] = None,
        has_charge_controller: bool = False,
    ) -> Dict[str, Union[str, float, bool, None]]:
        """
        Evaluate instantaneous microgrid power balance.
        """
        target_load = load_power_w if load_power_w is not None else self.load_power_w

        if solar_power_w is None or solar_power_w < 0:
            return {
                "status": MicrogridStatus.INSUFFICIENT_DATA.value,
                "solar_power_w": 0.0,
                "load_power_w": target_load,
                "net_power_w": -target_load,
                "surplus_w": 0.0,
                "deficit_w": target_load,
                "action_recommendation": "Awaiting valid sensor telemetry.",
                "battery_advisory": "Battery status unavailable.",
                "battery_soc_pct": None,
                "storage_recommended": False,
            }

        p_solar = float(solar_power_w)
        net_power = p_solar - target_load
        soc = self.estimate_battery_soc(battery_voltage_v)

        if net_power >= 0:
            status = MicrogridStatus.SOLAR_SUFFICIENT
            surplus = round(net_power, 3)
            deficit = 0.0
            action = f"Solar power ({p_solar:.2f} W) fully supports the connected load ({target_load:.2f} W)."

            if surplus > 0.5:
                if has_charge_controller:
                    storage_rec = True
                    batt_advice = (
                        f"Surplus {surplus:.2f} W available for battery storage via verified charge controller."
                    )
                else:
                    storage_rec = False
                    batt_advice = (
                        f"Surplus {surplus:.2f} W available, but battery storage disabled. "
                        "Connect a dedicated solar charge controller (e.g., TP4056 or MPPT) with BMS before storing energy."
                    )
            else:
                storage_rec = False
                batt_advice = "Generation closely matches load. Negligible surplus for battery charging."
        else:
            status = MicrogridStatus.SOLAR_INSUFFICIENT
            surplus = 0.0
            deficit = round(abs(net_power), 3)
            action = (
                f"Solar deficit of {deficit:.2f} W detected. Supplemental energy required to sustain {target_load:.2f} W load."
            )
            storage_rec = False

            if soc is not None:
                if soc > 20.0:
                    batt_advice = f"Battery at {soc:.1f}% SoC can deliver supplemental energy via safe step-up converter."
                else:
                    batt_advice = (
                        f"CRITICAL: Battery SoC is low ({soc:.1f}%). Shed non-essential load to protect cell from over-discharge."
                    )
            else:
                batt_advice = "No battery voltage telemetry detected. Consider connecting supplemental grid/battery reserve."

        return {
            "status": status.value,
            "solar_power_w": round(p_solar, 3),
            "load_power_w": round(target_load, 3),
            "net_power_w": round(net_power, 3),
            "surplus_w": surplus,
            "deficit_w": deficit,
            "action_recommendation": action,
            "battery_advisory": batt_advice,
            "battery_soc_pct": soc,
            "storage_recommended": storage_rec,
        }
