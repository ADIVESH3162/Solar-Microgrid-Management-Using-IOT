"""
Feature Engineering Module
Constructs cyclical temporal features, lag variables, and rolling statistics
for solar power regression forecasting.
"""

import logging
import sys
from pathlib import Path
from typing import List, Tuple

# Ensure project root is on sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import numpy as np
import pandas as pd

from src.config import FEATURE_COLS, TARGET_COL

logger = logging.getLogger(__name__)


def create_features(df: pd.DataFrame, is_training: bool = True) -> pd.DataFrame:
    """
    Generate model features from raw solar telemetry dataframe:
    - Hour, Minute
    - Sin/Cos cyclic hour encoding
    - Lag features (lux_lag_1)
    - Rolling window statistics (lux_rolling_3, temp_rolling_3)
    """
    if df.empty:
        return pd.DataFrame(columns=FEATURE_COLS + ([TARGET_COL] if is_training else []))

    data = df.copy()

    # Ensure timestamp datetime
    if "timestamp" in data.columns and not pd.api.types.is_datetime64_any_dtype(data["timestamp"]):
        data["timestamp"] = pd.to_datetime(data["timestamp"], errors="coerce")

    # Time cyclic features
    if "timestamp" in data.columns and data["timestamp"].notna().any():
        hours = data["timestamp"].dt.hour.fillna(12)
        minutes = data["timestamp"].dt.minute.fillna(0)
    else:
        hours = pd.Series([12] * len(data))
        minutes = pd.Series([0] * len(data))

    data["hour"] = hours
    data["minute"] = minutes
    data["hour_sin"] = np.sin(2.0 * np.pi * (hours + minutes / 60.0) / 24.0)
    data["hour_cos"] = np.cos(2.0 * np.pi * (hours + minutes / 60.0) / 24.0)

    # Sensor numeric defaults
    for col in ["light_lux", "temperature_c", "humidity_pct"]:
        if col not in data.columns:
            data[col] = 0.0
        data[col] = pd.to_numeric(data[col], errors="coerce").fillna(0.0)

    # Lag & Rolling features
    data["lux_lag_1"] = data["light_lux"].shift(1).fillna(data["light_lux"])
    data["temp_rolling_3"] = data["temperature_c"].rolling(window=3, min_periods=1).mean().fillna(data["temperature_c"])
    data["lux_rolling_3"] = data["light_lux"].rolling(window=3, min_periods=1).mean().fillna(data["light_lux"])

    if is_training and TARGET_COL in data.columns:
        data[TARGET_COL] = pd.to_numeric(data[TARGET_COL], errors="coerce")
        # Filter rows where target is NaN
        data = data.dropna(subset=[TARGET_COL])

    return data


def prepare_train_test_data(
    df: pd.DataFrame,
    split_ratio: float = 0.8
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
    """
    Perform chronological train/test split (no shuffling) to respect time series causality.
    """
    featured_df = create_features(df, is_training=True)
    if featured_df.empty or len(featured_df) < 5:
        raise ValueError("Insufficient records to generate train/test splits.")

    X = featured_df[FEATURE_COLS]
    y = featured_df[TARGET_COL]

    split_idx = int(len(X) * split_ratio)
    split_idx = max(1, min(split_idx, len(X) - 1))

    X_train = X.iloc[:split_idx]
    X_test = X.iloc[split_idx:]
    y_train = y.iloc[:split_idx]
    y_test = y.iloc[split_idx:]

    return X_train, X_test, y_train, y_test
