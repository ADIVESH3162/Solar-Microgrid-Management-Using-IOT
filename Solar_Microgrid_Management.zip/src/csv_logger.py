"""
CSV Logger Module
Thread-safe and fault-tolerant CSV logging engine.
Ensures strict schema conformance, prevents duplicate records, maintains raw data integrity,
and strictly enforces that only genuine hardware measurements can be appended to the live dataset.
"""

import csv
import logging
import sys
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

# Ensure project root is on sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import pandas as pd

from src.config import (
    CSV_COLUMNS,
    DATA_SOURCE_HARDWARE,
    LIVE_CSV_COLUMNS,
    LIVE_CSV_PATH,
)

logger = logging.getLogger(__name__)


class CSVLogger:
    """
    Manages appending validated solar telemetry records to CSV files.
    Ensures headers exist, column order is strictly preserved, and timestamps are deduplicated.
    Includes thread-safe locking and an explicit safeguard against logging synthetic/demo data to live files.
    """

    def __init__(
        self,
        target_filepath: Path = LIVE_CSV_PATH,
        columns: Optional[List[str]] = None,
    ):
        self.target_filepath = Path(target_filepath)
        self.columns = list(columns) if columns else list(LIVE_CSV_COLUMNS)
        self.last_logged_timestamp: Optional[str] = None
        self._lock = threading.Lock()
        self._ensure_file_initialized()

    def _ensure_file_initialized(self):
        """Create target CSV file with standard headers if missing or empty, preserving existing data."""
        with self._lock:
            self.target_filepath.parent.mkdir(parents=True, exist_ok=True)
            if not self.target_filepath.exists() or self.target_filepath.stat().st_size == 0:
                with open(self.target_filepath, mode="w", newline="", encoding="utf-8") as f:
                    writer = csv.DictWriter(f, fieldnames=self.columns)
                    writer.writeheader()
                logger.info(f"Initialized new CSV dataset with {len(self.columns)} columns at {self.target_filepath}")
            else:
                # Read header and last record timestamp to avoid duplicate appends across reboots
                try:
                    df = pd.read_csv(self.target_filepath)
                    if not df.empty and "timestamp" in df.columns:
                        self.last_logged_timestamp = str(df.iloc[-1]["timestamp"])
                    # If file has existing columns, ensure we respect them
                    if list(df.columns):
                        self.columns = list(df.columns)
                except Exception as ex:
                    logger.warning(f"Could not inspect header/timestamp in {self.target_filepath}: {ex}")

    def append_reading(self, reading: Dict[str, Union[float, str, None]]) -> bool:
        """
        Append a single validated sensor reading to the CSV file.
        Rejects exact duplicate timestamps to prevent clutter from UI refreshes.
        Rejects non-hardware readings if targeting the live dataset.
        """
        if not reading or "timestamp" not in reading:
            logger.warning("Attempted to log empty or un-timestamped record.")
            return False

        ts = str(reading["timestamp"])

        # Strict security guard: NEVER log synthetic or demo records to live CSV
        if self.target_filepath.resolve() == LIVE_CSV_PATH.resolve():
            source = str(reading.get("data_source", ""))
            if source not in (DATA_SOURCE_HARDWARE, "LIVE_ESP32"):
                logger.warning(
                    f"Blocked attempt to append non-hardware reading (source='{source}') to live dataset {self.target_filepath}"
                )
                return False

        with self._lock:
            if ts == self.last_logged_timestamp:
                logger.debug(f"Skipping duplicate record for timestamp {ts}")
                return False

            # Format record aligning strictly with canonical columns
            row = {}
            for col in self.columns:
                val = reading.get(col, None)
                row[col] = "" if val is None else val

            try:
                with open(self.target_filepath, mode="a", newline="", encoding="utf-8") as f:
                    writer = csv.DictWriter(f, fieldnames=self.columns)
                    writer.writerow(row)
                    f.flush()

                self.last_logged_timestamp = ts
                return True
            except Exception as ex:
                logger.error(f"Failed to append reading to {self.target_filepath}: {ex}")
                return False

    def append_batch(self, readings: List[Dict[str, Union[float, str, None]]]) -> int:
        """Append multiple readings in a single file transaction."""
        success_count = 0
        for r in readings:
            if self.append_reading(r):
                success_count += 1
        return success_count

    def get_record_count(self) -> int:
        """Return total number of data records logged in the CSV."""
        with self._lock:
            if not self.target_filepath.exists():
                return 0
            try:
                with open(self.target_filepath, mode="r", encoding="utf-8") as f:
                    count = sum(1 for _ in f) - 1
                    return max(0, count)
            except Exception as ex:
                logger.error(f"Error reading record count: {ex}")
                return 0

    def load_dataframe(self, max_rows: Optional[int] = None) -> pd.DataFrame:
        """
        Load logged records as a pandas DataFrame.
        Returns empty DataFrame with correct column names if file is empty.
        """
        with self._lock:
            if not self.target_filepath.exists() or self.target_filepath.stat().st_size == 0:
                return pd.DataFrame(columns=self.columns)
            try:
                if max_rows:
                    df = pd.read_csv(self.target_filepath).tail(max_rows)
                else:
                    df = pd.read_csv(self.target_filepath)
                return df
            except Exception as ex:
                logger.error(f"Error loading DataFrame from {self.target_filepath}: {ex}")
                return pd.DataFrame(columns=self.columns)

    def clear_file(self):
        """Truncate CSV file back to header row (used for clearing demo history)."""
        with self._lock:
            try:
                with open(self.target_filepath, mode="w", newline="", encoding="utf-8") as f:
                    writer = csv.DictWriter(f, fieldnames=self.columns)
                    writer.writeheader()
                self.last_logged_timestamp = None
                logger.info(f"Cleared CSV dataset at {self.target_filepath}")
                return True
            except Exception as ex:
                logger.error(f"Failed to clear CSV {self.target_filepath}: {ex}")
                return False
