"""
Serial Communication and Sensor Interface Module
Provides hardware discovery, serial reading, JSON line parsing, error handling,
validation against physical sensor boundaries, background logging worker,
and an isolated synthetic simulator mode for demonstration when ESP32 is offline.
"""

import json
import logging
import math
import random
import sys
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

# Ensure project root is on sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

try:
    import serial
    import serial.tools.list_ports
except ImportError:
    serial = None

from src.config import (
    DATA_SOURCE_DEMO,
    DATA_SOURCE_HARDWARE,
    DEFAULT_BAUD_RATE,
    DEFAULT_TIMEOUT_SEC,
    ESP32_CHIP_IDENTIFIERS,
    MAX_SAFE_CURRENT_MA,
    MAX_SAFE_TEMPERATURE_C,
    MAX_SAFE_VOLTAGE_V,
    MIN_SAFE_TEMPERATURE_C,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def list_available_ports() -> List[Dict[str, str]]:
    """Enumerate all available physical and virtual serial COM ports."""
    ports_info = []
    if serial is None:
        logger.warning("pyserial is not installed.")
        return ports_info

    for port in serial.tools.list_ports.comports():
        ports_info.append(
            {
                "device": port.device,
                "description": port.description or "Unknown Device",
                "hwid": port.hwid or "",
            }
        )
    return ports_info


def detect_esp32_port() -> Optional[str]:
    """
    Attempt to auto-detect an ESP32 board attached to USB.
    Searches for common USB-to-UART bridge controller chips (CP210x, CH340, etc.).
    """
    available = list_available_ports()
    for port in available:
        desc = (port["description"] + " " + port["hwid"]).upper()
        for chip in ESP32_CHIP_IDENTIFIERS:
            if chip.upper() in desc:
                logger.info(f"Auto-detected ESP32 on port {port['device']} ({port['description']})")
                return port["device"]

    # Fallback to the first available COM port if only one is present
    if len(available) == 1:
        logger.info(f"Selecting sole available port {available[0]['device']}")
        return available[0]["device"]

    return None


class SerialSensorReader:
    """
    Reads and validates streaming sensor telemetry from ESP32 over USB Serial.
    Expects newline-delimited JSON strings with validated sensor readings.
    Provides background thread acquisition to prevent UI blocking and eliminate duplicate records.
    """

    def __init__(
        self,
        port: Optional[str] = None,
        baud_rate: int = DEFAULT_BAUD_RATE,
        timeout: float = DEFAULT_TIMEOUT_SEC,
    ):
        self.port = port
        self.baud_rate = baud_rate
        self.timeout = timeout
        self.serial_conn: Optional[serial.Serial] = None
        self.is_connected = False
        self.last_error = ""
        self.latest_reading: Optional[Dict[str, Any]] = None
        self.last_successful_timestamp: Optional[str] = None
        self.valid_reading_count: int = 0
        self.csv_logger: Optional[Any] = None

        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._worker_thread: Optional[threading.Thread] = None

    def connect(self, port: Optional[str] = None, csv_logger: Optional[Any] = None) -> bool:
        """Establish serial connection to ESP32 and start continuous background reading."""
        if serial is None:
            self.last_error = "pyserial library not available"
            return False

        # Disconnect any prior connection cleanly
        self.disconnect()

        target_port = port or self.port or detect_esp32_port()
        if not target_port:
            self.last_error = "No serial port specified or detected"
            return False

        try:
            self.serial_conn = serial.Serial(
                port=target_port,
                baudrate=self.baud_rate,
                timeout=self.timeout,
                write_timeout=self.timeout,
            )
            # Flush existing buffer to avoid stale boot packets
            self.serial_conn.reset_input_buffer()
            self.port = target_port
            self.is_connected = True
            self.last_error = ""
            self.csv_logger = csv_logger
            self._stop_event.clear()

            # Launch background reader thread for continuous reliable logging
            self._worker_thread = threading.Thread(
                target=self._reader_worker,
                name="ESP32-SerialReaderWorker",
                daemon=True,
            )
            self._worker_thread.start()

            logger.info(f"Connected to ESP32 on {target_port} at {self.baud_rate} baud (Background reader active)")
            return True
        except (serial.SerialException, OSError) as ex:
            self.is_connected = False
            self.last_error = f"Serial connection error: {ex}"
            logger.error(self.last_error)
            return False

    def disconnect(self):
        """Safely stop background thread and close serial port connection."""
        self._stop_event.set()
        if self._worker_thread and self._worker_thread.is_alive():
            self._worker_thread.join(timeout=1.0)
        self._worker_thread = None

        if self.serial_conn and self.serial_conn.is_open:
            try:
                self.serial_conn.close()
            except Exception as ex:
                logger.warning(f"Error while closing serial connection: {ex}")
        self.serial_conn = None
        self.is_connected = False
        logger.info("Serial connection closed")

    def _reader_worker(self):
        """Background thread worker continuously reading and logging serial packets."""
        while not self._stop_event.is_set() and self.is_connected:
            reading = self._read_single_packet()
            if reading:
                with self._lock:
                    self.latest_reading = reading
                    self.last_successful_timestamp = reading.get("timestamp")
                    self.valid_reading_count += 1

                # Automatically append to attached live CSV logger
                if self.csv_logger is not None:
                    try:
                        self.csv_logger.append_reading(reading)
                    except Exception as ex:
                        logger.error(f"Error logging reading from background thread: {ex}")

            # Short non-blocking sleep to avoid CPU spinning if buffer is dry
            time.sleep(0.05)

    def _read_single_packet(self) -> Optional[Dict[str, Any]]:
        """Read and validate a single newline-delimited JSON line from the serial port."""
        if not self.serial_conn or not self.serial_conn.is_open:
            self.is_connected = False
            return None

        try:
            raw_line = self.serial_conn.readline()
            if not raw_line:
                return None

            line_str = raw_line.decode("utf-8", errors="replace").strip()
            if not line_str:
                return None

            # Skip initial boot messages or debug prints that are not JSON
            if not (line_str.startswith("{") and line_str.endswith("}")):
                logger.debug(f"Skipping non-JSON serial line: {line_str}")
                return None

            parsed = json.loads(line_str)
            if "event" in parsed and parsed["event"] == "INIT":
                logger.info(f"ESP32 Startup Notification received: {parsed}")
                return None

            return self._validate_and_sanitize(parsed)

        except (serial.SerialException, OSError) as ex:
            self.is_connected = False
            self.last_error = f"Serial link disconnected: {ex}"
            logger.warning(self.last_error)
            return None
        except json.JSONDecodeError as ex:
            logger.debug(f"Corrupted serial packet dropped: {ex}")
            return None

    def read_reading(self) -> Optional[Dict[str, Any]]:
        """
        Public reading API:
        Returns latest reading from background thread, or reads one packet synchronously if thread inactive.
        """
        if self._worker_thread and self._worker_thread.is_alive():
            return self.get_latest_reading()
        return self._read_single_packet()

    def get_latest_reading(self) -> Optional[Dict[str, Any]]:
        """Thread-safe getter for the most recently received validated reading."""
        with self._lock:
            return dict(self.latest_reading) if self.latest_reading else None

    def _validate_and_sanitize(self, raw: dict) -> Optional[Dict[str, Any]]:
        """
        Validate raw sensor measurements against physical bounds and module status.
        Rejects invalid or incomplete measurements.
        Converts missing or failed sensor readings to None (displayed as N/A), never invented values.
        Calculates power strictly as Power (W) = Voltage (V) * Current (A).
        """
        now_iso = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # 1. Temperature validation (DHT22: -40°C to +80°C; safe ambient bounds: -10°C to 65°C)
        temp = raw.get("temp")
        if temp is not None:
            try:
                temp = float(temp)
                if not (MIN_SAFE_TEMPERATURE_C <= temp <= MAX_SAFE_TEMPERATURE_C):
                    temp = None
            except (ValueError, TypeError):
                temp = None

        # 2. Humidity validation (0.0% to 100.0%)
        humidity = raw.get("humidity")
        if humidity is not None:
            try:
                humidity = float(humidity)
                if not (0.0 <= humidity <= 100.0):
                    humidity = None
            except (ValueError, TypeError):
                humidity = None

        # 3. Light intensity validation (BH1750: 0.0 to 120,000 lux)
        lux = raw.get("lux")
        if lux is not None:
            try:
                lux = float(lux)
                if not (0.0 <= lux <= 120000.0):
                    lux = None
            except (ValueError, TypeError):
                lux = None

        # 4. Solar voltage validation (0.0V to MAX_SAFE_VOLTAGE_V)
        voltage = raw.get("voltage")
        if voltage is not None:
            try:
                voltage = float(voltage)
                if not (0.0 <= voltage <= MAX_SAFE_VOLTAGE_V):
                    voltage = None
            except (ValueError, TypeError):
                voltage = None

        # 5. Solar current validation (INA219: 0.0mA to MAX_SAFE_CURRENT_MA)
        current = raw.get("current_ma")
        if current is not None:
            try:
                current = float(current)
                # Small reverse noise around shunt resistor zero-point (-5mA to 0mA) clamped to 0
                if -5.0 <= current < 0.0:
                    current = 0.0
                elif not (0.0 <= current <= MAX_SAFE_CURRENT_MA):
                    current = None
            except (ValueError, TypeError):
                current = None

        # 6. Correct physical power calculation: Power (W) = Voltage (V) * Current (A)
        # Convert current from mA to A before calculating power.
        if voltage is not None and current is not None:
            current_a = current / 1000.0
            power = round(voltage * current_a, 3)
            if power < 0.0:
                power = 0.0
        else:
            power = None

        # Determine composite sensor status string
        if "status" in raw and raw["status"]:
            status_str = raw["status"]
        else:
            errors = []
            if temp is None or humidity is None:
                errors.append("DHT_ERR")
            if lux is None:
                errors.append("BH1750_ERR")
            if voltage is None or current is None:
                errors.append("INA219_ERR")
            status_str = "OK" if not errors else ";".join(errors)

        return {
            "timestamp": now_iso,
            "temperature_c": temp,
            "humidity_pct": humidity,
            "light_lux": lux,
            "solar_voltage_v": voltage,
            "solar_current_ma": current,
            "solar_power_w": power,
            "data_source": DATA_SOURCE_HARDWARE,
            "sensor_status": status_str,
        }


class SimulatorSensorReader:
    """
    Synthetic physics-grounded solar microgrid telemetry generator.
    Simulates diurnal sun motion, atmospheric attenuation, cloud transients,
    and PV module I-V characteristics for testing when hardware is offline.
    
    IMPORTANT: This class is STRICTLY for DEMO MODE.
    Records are explicitly tagged as 'SIMULATED_DEMO'.
    NEVER writes to the live dataset.
    """

    def __init__(
        self,
        panel_rated_watts: float = 10.0,
        base_temp_c: float = 28.0,
        rated_watts: Optional[float] = None,
    ):
        self.panel_rated_watts = rated_watts if rated_watts is not None else panel_rated_watts
        self.base_temp_c = base_temp_c
        self.cum_energy_wh = 0.0
        self.last_timestamp = time.time()
        self.cloud_factor = 1.0

    def read_reading(self) -> Dict[str, Union[float, str, None]]:
        """Generate one physics-consistent simulated telemetry frame tagged as SIMULATED_DEMO."""
        now = datetime.now()
        hour_fraction = now.hour + now.minute / 60.0 + now.second / 3600.0

        # Solar zenith angle simulation (Sunrise ~ 06:00, Sunset ~ 18:00)
        if 6.0 <= hour_fraction <= 18.0:
            solar_elevation = math.sin((hour_fraction - 6.0) / 12.0 * math.pi)
            if random.random() < 0.08:
                self.cloud_factor = random.uniform(0.35, 0.95)
            elif random.random() < 0.15:
                self.cloud_factor = min(1.0, self.cloud_factor + 0.1)

            clear_sky_lux = 85000.0 * (solar_elevation ** 1.1)
            lux = max(100.0, round(clear_sky_lux * self.cloud_factor + random.gauss(0, 500), 1))
            temp_c = round(self.base_temp_c + (solar_elevation * 6.5) + random.gauss(0, 0.3), 1)
            humidity = round(max(20.0, min(95.0, 70.0 - (solar_elevation * 30.0) + random.gauss(0, 0.5))), 1)

            voltage = round(max(0.5, 12.0 + (3.5 * solar_elevation * self.cloud_factor) + random.gauss(0, 0.1)), 2)
            effective_irradiance = lux / 85000.0
            power_w = round(max(0.0, self.panel_rated_watts * effective_irradiance * (1.0 - 0.004 * (temp_c - 25.0))), 3)
            current_ma = round((power_w / voltage) * 1000.0, 1) if voltage > 0.1 else 0.0
        else:
            lux = round(max(0.0, random.uniform(0.0, 5.0)), 1)
            temp_c = round(self.base_temp_c - 4.0 + random.gauss(0, 0.2), 1)
            humidity = round(min(98.0, 80.0 + random.gauss(0, 0.5)), 1)
            voltage = 0.0
            current_ma = 0.0
            power_w = 0.0

        current_time = time.time()
        dt_hours = (current_time - self.last_timestamp) / 3600.0
        self.last_timestamp = current_time
        if 0 < dt_hours < 0.1:
            self.cum_energy_wh += power_w * dt_hours

        return {
            "timestamp": now.strftime("%Y-%m-%d %H:%M:%S"),
            "temperature_c": temp_c,
            "humidity_pct": humidity,
            "light_lux": lux,
            "solar_voltage_v": voltage,
            "solar_current_ma": current_ma,
            "solar_power_w": power_w,
            "data_source": DATA_SOURCE_DEMO,
            "sensor_status": "SIMULATED",
        }
