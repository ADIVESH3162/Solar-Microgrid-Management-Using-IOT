"""
Data Processor and Analytical Aggregation Module
Handles data cleaning, unit conversions, missing-value imputation,
numerical trapezoidal energy integration (Wh), and rolling summary statistics.
"""

import logging
from typing import Dict, Optional, Tuple, Union

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


def clean_and_prepare_timeseries(df: pd.DataFrame) -> pd.DataFrame:
    """
    Sanitize dataframe: ensure chronological sorting, convert timestamp to datetime,
    coerce numerical types, and handle empty frames gracefully.
    """
    if df.empty:
        return df.copy()

    processed = df.copy()

    # Convert timestamp
    if "timestamp" in processed.columns:
        processed["timestamp"] = pd.to_datetime(processed["timestamp"], errors="coerce")
        processed = processed.dropna(subset=["timestamp"])
        processed = processed.sort_values(by="timestamp").reset_index(drop=True)

    numeric_cols = [
        "temperature_c",
        "humidity_pct",
        "light_lux",
        "solar_voltage_v",
        "solar_current_ma",
        "solar_power_w",
        "battery_voltage_v",
        "battery_current_ma",
        "battery_soc_pct",
        "load_power_w",
        "energy_wh",
    ]

    for col in numeric_cols:
        if col in processed.columns:
            processed[col] = pd.to_numeric(processed[col], errors="coerce")

    # If solar_power_w is missing but voltage and current exist, calculate it
    if "solar_power_w" in processed.columns and "solar_voltage_v" in processed.columns and "solar_current_ma" in processed.columns:
        mask = processed["solar_power_w"].isna() & processed["solar_voltage_v"].notna() & processed["solar_current_ma"].notna()
        processed.loc[mask, "solar_power_w"] = (
            processed.loc[mask, "solar_voltage_v"] * processed.loc[mask, "solar_current_ma"] / 1000.0
        ).round(3)

    return processed


def compute_cumulative_energy_wh(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate cumulative energy in Watt-hours (Wh) via trapezoidal numerical integration:
    E = sum( 0.5 * (P_i + P_{i-1}) * delta_t_hours )
    """
    if df.empty or len(df) < 2 or "solar_power_w" not in df.columns or "timestamp" not in df.columns:
        if not df.empty and "energy_wh" not in df.columns:
            df["energy_wh"] = 0.0
        return df

    processed = clean_and_prepare_timeseries(df)
    times = processed["timestamp"]
    powers = processed["solar_power_w"].fillna(0.0).clip(lower=0.0).values

    time_diff_sec = times.diff().dt.total_seconds().fillna(0.0).values

    # Cap delta-t at 300 seconds (5 min) to prevent massive jumps over long outages
    time_diff_sec = np.clip(time_diff_sec, 0.0, 300.0)
    time_diff_hours = time_diff_sec / 3600.0

    # Trapezoidal step: (P1 + P2) / 2 * dt
    segment_energies = np.zeros(len(processed))
    for i in range(1, len(processed)):
        segment_energies[i] = 0.5 * (powers[i] + powers[i - 1]) * time_diff_hours[i]

    processed["energy_wh"] = np.cumsum(segment_energies).round(4)
    return processed


def compute_daily_summary(df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute daily solar generation metrics:
    Peak Power (W), Total Energy Generated (Wh), Average Sunlight (lux), Max Temp (°C).
    """
    if df.empty or "timestamp" not in df.columns:
        return pd.DataFrame(
            columns=["date", "total_energy_wh", "peak_power_w", "avg_lux", "max_temp_c", "records_count"]
        )

    processed = clean_and_prepare_timeseries(df)
    processed["date"] = processed["timestamp"].dt.date

    summary = (
        processed.groupby("date")
        .agg(
            peak_power_w=("solar_power_w", "max"),
            avg_lux=("light_lux", "mean"),
            max_temp_c=("temperature_c", "max"),
            records_count=("timestamp", "count"),
        )
        .reset_index()
    )

    # Calculate actual energy per day
    daily_energies = []
    for d, group in processed.groupby("date"):
        group_with_energy = compute_cumulative_energy_wh(group)
        if "energy_wh" in group_with_energy.columns and not group_with_energy.empty:
            daily_energies.append(group_with_energy["energy_wh"].iloc[-1])
        else:
            daily_energies.append(0.0)

    summary["total_energy_wh"] = [round(e, 2) for e in daily_energies]
    summary["avg_lux"] = summary["avg_lux"].round(1)
    summary["peak_power_w"] = summary["peak_power_w"].round(3)
    return summary


def get_system_kpis(df: pd.DataFrame, default_load_w: float = 5.0) -> Dict[str, Union[float, str, int, None]]:
    """
    Extract high-level real-time KPI metrics for dashboard summary cards.
    Returns None for missing or unmeasured metrics so UI displays genuine 'N/A' rather than invented zeros.
    """
    if df.empty:
        return {
            "current_power_w": None,
            "current_voltage_v": None,
            "current_current_ma": None,
            "current_lux": None,
            "current_temp_c": None,
            "current_humidity_pct": None,
            "total_energy_wh": 0.0,
            "peak_power_w": 0.0,
            "total_records": 0,
            "last_timestamp": "No Data",
            "solar_sufficiency": "INSUFFICIENT_DATA",
            "surplus_deficit_w": -default_load_w,
        }

    processed = clean_and_prepare_timeseries(df)
    latest = processed.iloc[-1]

    def _to_float(v):
        if pd.isna(v) or v is None or v == "":
            return None
        try:
            return float(v)
        except (ValueError, TypeError):
            return None

    curr_p = _to_float(latest.get("solar_power_w"))
    curr_v = _to_float(latest.get("solar_voltage_v"))
    curr_i = _to_float(latest.get("solar_current_ma"))
    curr_lux = _to_float(latest.get("light_lux"))
    curr_t = _to_float(latest.get("temperature_c"))
    curr_h = _to_float(latest.get("humidity_pct"))

    valid_powers = processed["solar_power_w"].dropna() if "solar_power_w" in processed else pd.Series(dtype=float)
    peak_p = float(valid_powers.max()) if not valid_powers.empty else 0.0

    # Compute total energy from valid records
    with_energy = compute_cumulative_energy_wh(processed)
    total_e = float(with_energy["energy_wh"].iloc[-1] if "energy_wh" in with_energy and not with_energy.empty else 0.0)

    if curr_p is not None:
        surplus = round(curr_p - default_load_w, 3)
        sufficiency = "SOLAR_SUFFICIENT" if curr_p >= default_load_w else "SOLAR_INSUFFICIENT"
    else:
        surplus = None
        sufficiency = "AWAITING_DATA"

    ts_str = str(latest.get("timestamp"))

    return {
        "current_power_w": round(curr_p, 3) if curr_p is not None else None,
        "current_voltage_v": round(curr_v, 2) if curr_v is not None else None,
        "current_current_ma": round(curr_i, 1) if curr_i is not None else None,
        "current_lux": round(curr_lux, 1) if curr_lux is not None else None,
        "current_temp_c": round(curr_t, 1) if curr_t is not None else None,
        "current_humidity_pct": round(curr_h, 1) if curr_h is not None else None,
        "total_energy_wh": round(total_e, 3),
        "peak_power_w": round(peak_p, 3),
        "total_records": len(processed),
        "last_timestamp": ts_str,
        "solar_sufficiency": sufficiency,
        "surplus_deficit_w": surplus,
    }
