"""
Alerts and Anomaly Detection Module
Monitors telemetry streams for physical parameter violations, sensor hardware failures,
thermal risks, and electrical over-range conditions.
"""

import logging
import sys
from pathlib import Path
from typing import Dict, List, Optional, Union

# Ensure project root is on sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.config import (
    BATTERY_CUTOFF_V,
    BATTERY_FULL_V,
    MAX_SAFE_CURRENT_MA,
    MAX_SAFE_TEMPERATURE_C,
    MAX_SAFE_VOLTAGE_V,
    MIN_SAFE_TEMPERATURE_C,
)

logger = logging.getLogger(__name__)


class AlertLevel:
    INFO = "INFO"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"


def evaluate_telemetry_alerts(reading: Dict[str, Union[float, str, None]]) -> List[Dict[str, str]]:
    """
    Check an individual telemetry record against electrical and environmental safety boundaries.
    """
    alerts = []
    if not reading:
        return alerts

    ts = str(reading.get("timestamp", "NOW"))

    # 1. Hardware Sensor Errors
    sensor_status = str(reading.get("sensor_status", "OK"))
    if "DHT_ERR" in sensor_status:
        alerts.append({
            "level": AlertLevel.WARNING,
            "title": "DHT22 Sensor Fault",
            "message": "Temperature/humidity sensor communication failed. Check GPIO4 connection.",
            "timestamp": ts,
        })
    if "BH1750_ERR" in sensor_status:
        alerts.append({
            "level": AlertLevel.WARNING,
            "title": "BH1750 Sensor Fault",
            "message": "Ambient light sensor I2C timeout on address 0x23. Check SDA/SCL pins.",
            "timestamp": ts,
        })
    if "INA219_ERR" in sensor_status:
        alerts.append({
            "level": AlertLevel.CRITICAL,
            "title": "INA219 Power Monitor Offline",
            "message": "Current/voltage monitor I2C timeout on address 0x40. Power measurement suspended.",
            "timestamp": ts,
        })

    # 2. Voltage Check
    v = reading.get("solar_voltage_v")
    if v is not None:
        try:
            v_val = float(v)
            if v_val >= MAX_SAFE_VOLTAGE_V:
                alerts.append({
                    "level": AlertLevel.CRITICAL,
                    "title": "Solar Overvoltage Alert",
                    "message": f"Measured voltage ({v_val:.1f} V) exceeds safe threshold ({MAX_SAFE_VOLTAGE_V:.1f} V).",
                    "timestamp": ts,
                })
        except (ValueError, TypeError):
            pass

    # 3. Current Check
    i = reading.get("solar_current_ma")
    if i is not None:
        try:
            i_val = float(i)
            if i_val >= MAX_SAFE_CURRENT_MA:
                alerts.append({
                    "level": AlertLevel.CRITICAL,
                    "title": "Solar Overcurrent Alert",
                    "message": f"Measured current ({i_val:.1f} mA) exceeds shunt safe continuous rating ({MAX_SAFE_CURRENT_MA:.1f} mA).",
                    "timestamp": ts,
                })
        except (ValueError, TypeError):
            pass

    # 4. Temperature Check
    temp = reading.get("temperature_c")
    if temp is not None:
        try:
            t_val = float(temp)
            if t_val >= MAX_SAFE_TEMPERATURE_C:
                alerts.append({
                    "level": AlertLevel.CRITICAL,
                    "title": "PV Module High Temperature",
                    "message": f"Ambient temperature reached {t_val:.1f} °C. PV cell efficiency degrades rapidly; inspect ventilation.",
                    "timestamp": ts,
                })
            elif t_val <= MIN_SAFE_TEMPERATURE_C:
                alerts.append({
                    "level": AlertLevel.WARNING,
                    "title": "Low Temperature Warning",
                    "message": f"Freezing temperature ({t_val:.1f} °C) detected. Lithium battery charging below 0°C is hazardous.",
                    "timestamp": ts,
                })
        except (ValueError, TypeError):
            pass

    # 5. Battery Voltage Check (if present)
    b_volt = reading.get("battery_voltage_v")
    if b_volt is not None:
        try:
            bv = float(b_volt)
            if bv < BATTERY_CUTOFF_V:
                alerts.append({
                    "level": AlertLevel.CRITICAL,
                    "title": "18650 Battery Deep Discharge",
                    "message": f"Battery cell voltage ({bv:.2f} V) is below cut-off threshold ({BATTERY_CUTOFF_V:.1f} V). Disconnect load immediately.",
                    "timestamp": ts,
                })
            elif bv > BATTERY_FULL_V + 0.05:
                alerts.append({
                    "level": AlertLevel.CRITICAL,
                    "title": "18650 Battery Overvoltage",
                    "message": f"Cell voltage ({bv:.2f} V) exceeds 4.20V max threshold. Cut off charge source to avoid fire hazard.",
                    "timestamp": ts,
                })
        except (ValueError, TypeError):
            pass

    return alerts
