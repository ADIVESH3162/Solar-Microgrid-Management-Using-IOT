"""
Unit tests for Demo Data Generator Module
Verifies:
1. Telemetry structure and data_source='simulation_demo' tag.
2. Smooth value transitions (no wild jumps).
3. Power calculation consistency: Power (W) = Voltage (V) * (Current (mA) / 1000.0).
4. Configurable interval pacing and duplicate prevention.
5. Saving to solar_dataset_demo.csv while leaving solar_dataset_live.csv untouched.
6. Start / Stop control semantics.
7. History clearing functionality.
"""

import sys
import tempfile
import time
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import pandas as pd
import pytest

from src.config import (
    DATA_SOURCE_SIMULATION_DEMO,
    DEMO_CSV_COLUMNS,
    LIVE_CSV_COLUMNS,
)
from src.csv_logger import CSVLogger
from src.demo_data_generator import DemoDataGenerator


def test_demo_data_generator_reading_structure():
    """Verify generated reading contains all required fields and correct data_source."""
    gen = DemoDataGenerator(interval_sec=2.0)
    reading = gen.generate_next_reading()

    assert reading["data_source"] == DATA_SOURCE_SIMULATION_DEMO
    assert "timestamp" in reading
    assert 20.0 <= reading["temperature_c"] <= 50.0
    assert 20.0 <= reading["humidity_pct"] <= 90.0
    assert 5000.0 <= reading["light_lux"] <= 100000.0
    assert 10.0 <= reading["solar_voltage_v"] <= 20.0
    assert 40.0 <= reading["solar_current_ma"] <= 1200.0
    assert reading["solar_power_w"] > 0.0


def test_demo_data_generator_power_calculation():
    """Verify Power (W) is calculated as Voltage (V) * (Current (mA) / 1000.0)."""
    gen = DemoDataGenerator()
    reading = gen.generate_next_reading()

    v = reading["solar_voltage_v"]
    i_ma = reading["solar_current_ma"]
    p = reading["solar_power_w"]

    expected_p = round(v * (i_ma / 1000.0), 3)
    assert p == pytest.approx(expected_p, abs=0.001)


def test_demo_data_generator_smooth_transitions():
    """Verify readings transition smoothly between successive steps rather than jumping wildly."""
    gen = DemoDataGenerator(interval_sec=1.0)
    prev = gen.generate_next_reading()

    for _ in range(30):
        curr = gen.generate_next_reading()
        # Verify delta thresholds for smooth transition
        delta_v = abs(curr["solar_voltage_v"] - prev["solar_voltage_v"])
        delta_t = abs(curr["temperature_c"] - prev["temperature_c"])
        delta_h = abs(curr["humidity_pct"] - prev["humidity_pct"])

        assert delta_v < 1.5, f"Voltage jumped too abruptly: {delta_v} V"
        assert delta_t < 1.0, f"Temperature jumped too abruptly: {delta_t} °C"
        assert delta_h < 2.0, f"Humidity jumped too abruptly: {delta_h} %"

        prev = curr


def test_demo_data_generator_interval_pacing():
    """Verify step() respects interval_sec and does not generate duplicates when polled early."""
    gen = DemoDataGenerator(interval_sec=1.0)
    gen.is_running = True

    r1 = gen.step(force=True)
    assert r1 is not None

    # Immediate second poll without elapsed time should return the cached reading, not a new one
    r2 = gen.step(force=False)
    assert r2["timestamp"] == r1["timestamp"]
    assert len(gen.history) == 1


def test_demo_data_generator_saves_to_demo_csv():
    """Verify generated reading appends cleanly to the dedicated demo CSV file."""
    with tempfile.TemporaryDirectory() as tmpdir:
        demo_csv_path = Path(tmpdir) / "solar_dataset_demo.csv"
        demo_logger = CSVLogger(target_filepath=demo_csv_path, columns=DEMO_CSV_COLUMNS)

        gen = DemoDataGenerator(interval_sec=0.1)
        gen.is_running = True

        r1 = gen.step(csv_logger=demo_logger, force=True)
        assert demo_logger.get_record_count() == 1

        df = pd.read_csv(demo_csv_path)
        assert list(df.columns) == DEMO_CSV_COLUMNS
        assert df.iloc[0]["data_source"] == "simulation_demo"


def test_live_csv_remains_unmodified_by_demo_generator():
    """Verify demo generator never touches or pollutes the live hardware CSV."""
    with tempfile.TemporaryDirectory() as tmpdir:
        live_csv_path = Path(tmpdir) / "solar_dataset_live.csv"
        demo_csv_path = Path(tmpdir) / "solar_dataset_demo.csv"

        live_logger = CSVLogger(target_filepath=live_csv_path, columns=LIVE_CSV_COLUMNS)
        demo_logger = CSVLogger(target_filepath=demo_csv_path, columns=DEMO_CSV_COLUMNS)

        gen = DemoDataGenerator(interval_sec=0.1)
        gen.is_running = True

        # Generate 5 demo readings directed to demo_logger
        for _ in range(5):
            gen.step(csv_logger=demo_logger, force=True)
            time.sleep(0.01)

        assert demo_logger.get_record_count() == 5
        # Live dataset must remain completely untouched (0 rows)
        assert live_logger.get_record_count() == 0


def test_demo_generator_stop_halts_generation():
    """Verify stopping the simulation halts new reading generation."""
    gen = DemoDataGenerator(interval_sec=1.0)
    gen.is_running = False

    reading = gen.step(force=False)
    assert reading is None
    assert len(gen.history) == 0


def test_clear_demo_history():
    """Verify clearing demo history resets in-memory buffer and truncates CSV."""
    with tempfile.TemporaryDirectory() as tmpdir:
        demo_csv_path = Path(tmpdir) / "solar_dataset_demo.csv"
        demo_logger = CSVLogger(target_filepath=demo_csv_path, columns=DEMO_CSV_COLUMNS)

        gen = DemoDataGenerator(interval_sec=0.1)
        gen.is_running = True
        gen.step(csv_logger=demo_logger, force=True)
        gen.step(csv_logger=demo_logger, force=True)
        assert len(gen.history) == 2

        # Clear history
        gen.clear_history(clear_csv_path=demo_csv_path)
        assert len(gen.history) == 0
        assert gen.get_latest_reading() is None

        # Verify CSV has 0 rows and preserved header
        df = pd.read_csv(demo_csv_path)
        assert len(df) == 0
        assert list(df.columns) == DEMO_CSV_COLUMNS

