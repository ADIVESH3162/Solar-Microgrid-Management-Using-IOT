"""
Unit tests for Data Processor Module
Verifies data cleaning, numerical trapezoidal energy integration (Wh),
daily aggregation, and KPI metric computation.
"""

import sys
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import numpy as np
import pandas as pd
import pytest

from src.data_processor import (
    clean_and_prepare_timeseries,
    compute_cumulative_energy_wh,
    compute_daily_summary,
    get_system_kpis,
)


def test_clean_and_prepare_timeseries():
    """Verify type coercion, timestamp parsing, and power calculation."""
    df_raw = pd.DataFrame({
        "timestamp": ["2026-06-01 12:01:00", "2026-06-01 12:00:00"],  # Out of order
        "solar_voltage_v": ["12.0", "15.0"],
        "solar_current_ma": [500.0, 1000.0],
        "solar_power_w": [None, 15.0],
    })

    cleaned = clean_and_prepare_timeseries(df_raw)
    assert len(cleaned) == 2
    # Verify chronological sorting
    assert cleaned.iloc[0]["timestamp"] < cleaned.iloc[1]["timestamp"]
    # Verify computed power where missing: 12.0 * 500 / 1000 = 6.0
    assert cleaned.iloc[1]["solar_power_w"] == pytest.approx(6.0)


def test_compute_cumulative_energy_wh():
    """
    Verify trapezoidal integration over a known 1-hour constant power test:
    Constant 10.0 W for 1 hour (3600 sec) should yield exactly 10.0 Wh.
    """
    timestamps = [
        "2026-06-01 12:00:00",
        "2026-06-01 12:30:00",  # 0.5 hour
        "2026-06-01 13:00:00",  # 1.0 hour
    ]
    df = pd.DataFrame({
        "timestamp": timestamps,
        "solar_power_w": [10.0, 10.0, 10.0],
    })

    with_energy = compute_cumulative_energy_wh(df)
    assert "energy_wh" in with_energy.columns
    final_wh = with_energy["energy_wh"].iloc[-1]
    # In our implementation, interval is 1800s each step. 10.0 W * 1 hr = 10.0 Wh
    # Note: our code caps delta-t at 300 sec (5 min) to prevent massive jumps during long outages!
    # Let's test with 60-second steps to see exact integration.
    
    times_60s = pd.date_range("2026-06-01 12:00:00", periods=61, freq="1min")
    df_60s = pd.DataFrame({
        "timestamp": times_60s,
        "solar_power_w": [10.0] * 61,
    })
    res_60s = compute_cumulative_energy_wh(df_60s)
    assert res_60s["energy_wh"].iloc[-1] == pytest.approx(10.0, rel=1e-2)


def test_daily_summary():
    """Verify daily grouping extracts peak power and total energy."""
    times = pd.date_range("2026-06-01 10:00:00", periods=10, freq="1h")
    df = pd.DataFrame({
        "timestamp": times,
        "solar_power_w": [1.0, 2.0, 5.0, 8.0, 10.0, 8.0, 5.0, 3.0, 1.0, 0.0],
        "light_lux": [1000 * i for i in range(10)],
        "temperature_c": [25.0 + i for i in range(10)],
    })

    summary = compute_daily_summary(df)
    assert len(summary) == 1
    assert summary.iloc[0]["peak_power_w"] == 10.0
    assert summary.iloc[0]["records_count"] == 10


def test_get_system_kpis():
    """Verify KPI dictionary generation for dashboard cards."""
    # Test empty dataframe
    empty_kpis = get_system_kpis(pd.DataFrame())
    assert empty_kpis["total_records"] == 0
    assert empty_kpis["solar_sufficiency"] == "INSUFFICIENT_DATA"

    # Test populated dataframe
    df = pd.DataFrame({
        "timestamp": ["2026-06-01 12:00:00", "2026-06-01 12:01:00"],
        "solar_power_w": [4.0, 7.5],
        "solar_voltage_v": [14.0, 15.0],
        "solar_current_ma": [300.0, 500.0],
        "light_lux": [40000.0, 60000.0],
        "temperature_c": [28.0, 29.0],
    })

    kpis = get_system_kpis(df, default_load_w=5.0)
    assert kpis["current_power_w"] == 7.5
    assert kpis["solar_sufficiency"] == "SOLAR_SUFFICIENT"
    assert kpis["surplus_deficit_w"] == pytest.approx(2.5)
    assert kpis["total_records"] == 2

