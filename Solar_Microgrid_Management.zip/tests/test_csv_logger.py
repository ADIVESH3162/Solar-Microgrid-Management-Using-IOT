"""
Unit tests for CSV Logger Module
Verifies schema compliance, atomic file creation, duplicate prevention, and thread-safety.
"""

import sys
import tempfile
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import pandas as pd
import pytest

from src.config import CSV_COLUMNS
from src.csv_logger import CSVLogger


@pytest.fixture
def temp_csv_path():
    """Create a temporary CSV file path for testing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir) / "test_solar_live.csv"


def test_csv_logger_initialization(temp_csv_path):
    """Verify logger creates an empty CSV with correct headers."""
    logger = CSVLogger(target_filepath=temp_csv_path)
    assert temp_csv_path.exists()

    df = pd.read_csv(temp_csv_path)
    assert list(df.columns) == CSV_COLUMNS
    assert len(df) == 0
    assert logger.get_record_count() == 0


def test_csv_logger_append_reading(temp_csv_path):
    """Verify appending a valid record updates file and row count."""
    logger = CSVLogger(target_filepath=temp_csv_path)

    reading = {
        "timestamp": "2026-06-01 12:00:00",
        "temperature_c": 30.5,
        "humidity_pct": 50.0,
        "light_lux": 65000.0,
        "solar_voltage_v": 15.2,
        "solar_current_ma": 420.0,
        "solar_power_w": 6.384,
        "battery_voltage_v": None,
        "battery_current_ma": None,
        "battery_soc_pct": None,
        "load_power_w": 5.0,
        "energy_wh": 1.25,
        "data_source": "LIVE_ESP32",
        "sensor_status": "OK",
    }

    assert logger.append_reading(reading) is True
    assert logger.get_record_count() == 1

    df = logger.load_dataframe()
    assert len(df) == 1
    assert df.iloc[0]["solar_power_w"] == pytest.approx(6.384)
    assert df.iloc[0]["data_source"] == "LIVE_ESP32"


def test_csv_logger_duplicate_prevention(temp_csv_path):
    """Verify exact duplicate timestamps are rejected to prevent UI refresh bloat."""
    logger = CSVLogger(target_filepath=temp_csv_path)

    reading = {
        "timestamp": "2026-06-01 12:00:00",
        "temperature_c": 30.5,
        "humidity_pct": 50.0,
        "light_lux": 65000.0,
        "solar_power_w": 6.384,
        "data_source": "LIVE_ESP32",
        "sensor_status": "OK",
    }

    assert logger.append_reading(reading) is True
    # Attempt duplicate insert
    assert logger.append_reading(reading) is False
    assert logger.get_record_count() == 1

