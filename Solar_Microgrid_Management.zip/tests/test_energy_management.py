"""
Unit tests for Energy Management Module
Verifies power balance states (SOLAR_SUFFICIENT, SOLAR_INSUFFICIENT, INSUFFICIENT_DATA),
battery SoC estimations, and advisory safety notifications.
"""

import sys
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import pytest

from src.energy_management import EnergyManager, MicrogridStatus


def test_energy_balance_sufficient():
    """Verify SOLAR_SUFFICIENT when solar generation exceeds connected load."""
    mgr = EnergyManager(load_power_w=5.0)
    decision = mgr.evaluate_energy_balance(solar_power_w=8.2, load_power_w=5.0)

    assert decision["status"] == MicrogridStatus.SOLAR_SUFFICIENT.value
    assert decision["surplus_w"] == pytest.approx(3.2)
    assert decision["deficit_w"] == 0.0
    # By default, without charge controller, battery charging must not be recommended
    assert decision["storage_recommended"] is False
    assert "Connect a dedicated solar charge controller" in decision["battery_advisory"]


def test_energy_balance_sufficient_with_charge_controller():
    """Verify storage is recommended if verified charge controller is declared."""
    mgr = EnergyManager(load_power_w=5.0)
    decision = mgr.evaluate_energy_balance(
        solar_power_w=8.5, load_power_w=5.0, has_charge_controller=True
    )

    assert decision["status"] == MicrogridStatus.SOLAR_SUFFICIENT.value
    assert decision["storage_recommended"] is True
    assert "Surplus 3.50 W available for battery storage" in decision["battery_advisory"]


def test_energy_balance_insufficient():
    """Verify SOLAR_INSUFFICIENT when generation is below load requirement."""
    mgr = EnergyManager(load_power_w=5.0)
    decision = mgr.evaluate_energy_balance(solar_power_w=2.0, load_power_w=5.0)

    assert decision["status"] == MicrogridStatus.SOLAR_INSUFFICIENT.value
    assert decision["surplus_w"] == 0.0
    assert decision["deficit_w"] == pytest.approx(3.0)
    assert decision["storage_recommended"] is False


def test_energy_balance_no_data():
    """Verify INSUFFICIENT_DATA when sensor power is None."""
    mgr = EnergyManager(load_power_w=5.0)
    decision = mgr.evaluate_energy_balance(solar_power_w=None, load_power_w=5.0)

    assert decision["status"] == MicrogridStatus.INSUFFICIENT_DATA.value
    assert decision["storage_recommended"] is False


def test_battery_soc_estimation():
    """Verify 18650 SoC estimation curve."""
    mgr = EnergyManager()

    # Full battery
    assert mgr.estimate_battery_soc(4.25) == 100.0
    assert mgr.estimate_battery_soc(4.20) == 100.0

    # Nominal range
    soc_nom = mgr.estimate_battery_soc(3.82)
    assert soc_nom == pytest.approx(50.0, abs=1.0)

    # Low battery / cut-off
    assert mgr.estimate_battery_soc(3.0) == 0.0
    assert mgr.estimate_battery_soc(2.8) == 0.0

    # None input
    assert mgr.estimate_battery_soc(None) is None

