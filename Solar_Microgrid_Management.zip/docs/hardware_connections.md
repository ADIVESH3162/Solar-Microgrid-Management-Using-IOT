# Hardware Connections & Circuit Safety Guide

## 1. Complete Pin Interconnection Matrix

| Component | Pin Label | ESP32 Board Connection | Logic / Power | Function |
| :--- | :--- | :--- | :--- | :--- |
| **DHT22** | Pin 1 (VCC) | 3.3V (or VIN) | 3.3V DC | Sensor power input |
| **DHT22** | Pin 2 (DATA) | **GPIO 4** | 3.3V Logic | Single-bus bidirection data line (10k pull-up recommended) |
| **DHT22** | Pin 3 (NC) | Disconnected | - | Not connected internally |
| **DHT22** | Pin 4 (GND) | GND | 0V | Ground reference |
| **BH1750** | VCC | 3.3V | 3.3V DC | Ambient lux IC power |
| **BH1750** | GND | GND | 0V | Ground reference |
| **BH1750** | SCL | **GPIO 22** | 3.3V I2C Clock | Hardware I2C Clock (Bus 0) |
| **BH1750** | SDA | **GPIO 21** | 3.3V I2C Data | Hardware I2C Data (Bus 0) |
| **BH1750** | ADDR / ADD | GND | 0V | Pull to GND for address `0x23` |
| **INA219** | VCC | 3.3V | 3.3V DC | Digital logic power |
| **INA219** | GND | GND | 0V | Ground reference |
| **INA219** | SCL | **GPIO 22** | 3.3V I2C Clock | Hardware I2C Clock (Bus 0) |
| **INA219** | SDA | **GPIO 21** | 3.3V I2C Data | Hardware I2C Data (Bus 0) |
| **INA219** | **VIN+** | Solar Panel Positive (+) | Up to 26V DC | High-side sensing input from solar panel |
| **INA219** | **VIN-** | DC Load Positive (+) | Up to 26V DC | High-side sensing output to DC load |

---

## 2. Circuit Schematic & Current Shunt Wiring

The INA219 performs **high-side current sensing** by measuring the minute voltage drop across an onboard precision $0.1\,\Omega$ resistor located between `VIN+` and `VIN-`.

```
     +--------------------------------------------------------+
     |                  SOLAR PV PANEL (+)                    |
     +--------------------------------------------------------+
                                  │
                                  ▼
                         [ INA219 : VIN+ ]
                                  │
                          [ 0.1 Ohm Shunt ]
                                  │
                         [ INA219 : VIN- ]
                                  │
                                  ▼
     +--------------------------------------------------------+
     |                   DC LOAD INPUT (+)                    |
     +--------------------------------------------------------+

     +--------------------------------------------------------+
     |  SOLAR PV (-)  ────+                                   |
     |  DC LOAD (-)   ────┼───> [ ESP32 GND / COMMON GROUND ] |
     +--------------------------------------------------------+
```

### Why Common Ground is Crucial:
The ESP32 measures the I2C digital signals relative to its own GND pin. The INA219 bus voltage measurement is also referenced against its GND pin. Therefore, the negative wire of the solar panel and the negative wire of the DC load must connect to the common ground rail of the breadboard.

---

## 3. Mandatory Safety Requirements for Lithium Batteries

> [!CAUTION]
> **CRITICAL BATTERY SAFETY WARNING:**
> 1. **Never connect a bare 18650 lithium battery directly to a solar panel.**
>    - A typical small solar panel produces 18V to 21V open-circuit (Voc).
>    - A single 18650 lithium-ion cell has a maximum charge termination voltage of **4.20V $\pm$ 0.05V**.
>    - Connecting the cell directly causes extreme overcharging, thermal runaway, internal short-circuit, and violent venting or fire.
> 2. **Never connect a solar panel or battery to the ESP32 3.3V pin.**
>    - The ESP32 3.3V pin is the output of the onboard low-dropout linear regulator. Back-feeding high voltage into this pin will destroy the ESP32 chip instantly.
> 3. **Required Hardware for Battery Storage:**
>    - A dedicated CC/CV (Constant Current / Constant Voltage) solar charge controller (such as a TP4056 board equipped with DW01A protection IC) or an MPPT solar charge controller.
>    - A Battery Management System (BMS) with overcharge and over-discharge cutoff protection.
>    - An active DC-DC buck converter to step down panel voltage to 5V prior to reaching the charge controller.
> 4. **Advisory Software Logic:**
>    - The current version of this system operates in **advisory mode**. It computes whether surplus power exists and advises the operator. It does not actuate physical relays unless certified switching hardware is added.

---

## 4. Bench Testing Setup Guide

For initial software and firmware validation without a full rooftop solar panel:
1. **Powering ESP32:** Connect ESP32 via Micro-USB to the laptop. The onboard 3.3V regulator powers the sensors safely.
2. **Illuminance Testing:** Point a flashlight or smartphone torch at the BH1750. Observe the lux reading rise dynamically from 200 lx to over 30,000 lx on the dashboard.
3. **Electrical Testing:** Connect a small 5V USB source or 9V battery in series with a 100 $\Omega$ power resistor through INA219 `VIN+` and `VIN-`. The INA219 will register safe low-voltage DC current and power.
4. **Simulator Mode:** If hardware is not wired yet, toggle the **Simulator Mode** switch in the sidebar to stream realistic synthetic telemetry.

