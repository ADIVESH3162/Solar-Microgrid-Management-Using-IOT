# Testing and Verification Strategy

## 1. Automated Test Suite (pytest)

The project includes an automated unit test suite in `tests/` covering core backend components, data integrity, decision logic, and error handling.

To run the complete test suite:
```powershell
python -m pytest tests/ -v
```

### Test Coverage Summary:
| Test File | Test Cases | Objective | Status |
| :--- | :--- | :--- | :--- |
| `tests/test_csv_logger.py` | `test_csv_logger_initialization` | Verifies header creation and schema consistency | PASSED |
| | `test_csv_logger_append_reading` | Verifies atomic row writing and column ordering | PASSED |
| | `test_csv_logger_duplicate_prevention` | Verifies duplicate timestamp rejection | PASSED |
| `tests/test_data_processor.py`| `test_clean_and_prepare_timeseries`| Verifies type coercion and chronological sorting | PASSED |
| | `test_compute_cumulative_energy_wh` | Verifies trapezoidal energy integration accuracy | PASSED |
| | `test_daily_summary` | Verifies daily aggregation and peak detection | PASSED |
| | `test_get_system_kpis` | Verifies real-time KPI card generation | PASSED |
| `tests/test_energy_management.py`| `test_energy_balance_sufficient` | Verifies `SOLAR_SUFFICIENT` state when solar > load | PASSED |
| | `test_energy_balance_sufficient_with_charge_controller` | Verifies battery charging recommendation | PASSED |
| | `test_energy_balance_insufficient` | Verifies `SOLAR_INSUFFICIENT` and deficit calculation | PASSED |
| | `test_energy_balance_no_data` | Verifies graceful fallback to `INSUFFICIENT_DATA` | PASSED |
| | `test_battery_soc_estimation` | Verifies 18650 SoC estimation curve | PASSED |
| `tests/test_sensor_serial.py` | `test_serial_sanitization_valid` | Verifies JSON parsing and dictionary mapping | PASSED |
| | `test_serial_sanitization_out_of_bounds` | Verifies clipping impossible values to `None` | PASSED |
| | `test_simulator_sensor_reader` | Verifies synthetic generator produces valid records | PASSED |

**Result:** 15/15 unit tests passing ($100\%$ success rate).

---

## 2. Hardware Bench Test Protocols

Follow this step-by-step checklist to test the physical system:

### Test Protocol 1: Sensor Hardware Connectivity
1. Wire ESP32, DHT22, BH1750, and INA219 according to `docs/hardware_connections.md`.
2. Plug ESP32 into laptop USB.
3. Open Arduino Serial Monitor at 115200 baud.
4. **Verification Criteria:**
   - On startup, the sketch emits:
     `{"event":"INIT","dht22":"READY","bh1750":"READY","ina219":"READY","baud":115200}`.
   - Subsequent lines emit valid telemetry at 1-second intervals with `"status":"OK"`.

### Test Protocol 2: Irradiance Dynamic Response
1. Close Arduino Serial Monitor to release the COM port.
2. Launch dashboard with `run_project.bat`.
3. In the sidebar, select your COM port and click **Connect**.
4. Shine a flashlight onto the BH1750 sensor.
5. **Verification Criteria:**
   - BH1750 gauge and time-series chart instantly reflect increased lux.
   - Solar power forecast rises accordingly.

### Test Protocol 3: Solar Electrical Load Test
1. Connect a small solar panel to INA219 `VIN+` and a 5V USB lamp/fan to INA219 `VIN-`.
2. Verify voltage ($12\text{--}18\text{ V}$) and current ($100\text{--}800\text{ mA}$) display in real time.
3. Compare calculated power ($P = V \times I / 1000$) with the dashboard display.
4. **Verification Criteria:**
   - When solar generation exceeds the slider load demand, the status banner switches to **SOLAR SUFFICIENT**.
   - When the panel is shadowed, the status switches to **SOLAR INSUFFICIENT**.

### Test Protocol 4: Fault Tolerance & Disconnection Test
1. Unplug the ESP32 USB cable while the dashboard is running.
2. **Verification Criteria:**
   - The dashboard does NOT crash with an unhandled exception.
   - Connection badge switches to `HARDWARE DISCONNECTED`.
   - The CSV logger safely preserves existing records without truncating the file.

