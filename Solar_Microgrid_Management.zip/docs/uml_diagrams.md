# Software Engineering UML & Data Flow Diagrams

This document contains standard software engineering diagrams in Mermaid syntax for the AI-Based Solar Microgrid Management System.

---

## 1. Data Flow Diagram (DFD) - Level 0 (Context Diagram)

```mermaid
flowchart LR
    Sensors["Physical Sensors (DHT22, BH1750, INA219)"] -- "Analog/Digital Signals (V, I, Lux, Temp, Humidity)" --> ESP32["ESP32 Microcontroller Firmware"]
    ESP32 -- "JSON Lines Stream (115200 Baud)" --> System["AI Solar Microgrid Management System"]
    User["Operator / Engineer"] -- "Configures Load Demand (W) / Controls Port" --> System
    System -- "Visual Telemetry, Energy Yield (Wh), Predictions & Recommendations" --> User
    System -- "Live & Historical Datasets" --> Storage[("CSV Data Store")]
```

---

## 2. Data Flow Diagram (DFD) - Level 1

```mermaid
flowchart TD
    Sensors["Sensors (DHT22, BH1750, INA219)"] --> |Raw Physical Measurements| P1["1.0 Acquire & Format Telemetry (ESP32)"]
    P1 --> |JSON Lines over Serial| P2["2.0 Ingest, Validate & Sanitize (Python Host)"]
    
    P2 --> |Sanitized Telemetry Dict| D1[("solar_dataset_live.csv")]
    P2 --> |Cleaned Stream| P3["3.0 Analytical Energy Integration (DataProcessor)"]
    
    D1 --> |Historical Records| P4["4.0 Feature Engineering & ML Pipeline"]
    P4 --> |Trained Weights| D2[("solar_power_rf_model.joblib")]
    
    P3 --> |Integrated Wh, Peak Power| P5["5.0 Microgrid Decision & Alert Engine"]
    D2 --> |Predicted Solar Power| P5
    UserInputs["User Configured Load (W)"] --> P5
    
    P5 --> |Telemetry, Alerts, Balance & Forecasts| P6["6.0 Presentation & Visualization (Streamlit)"]
    P6 --> Operator["System Operator"]
```

---

## 3. Use Case Diagram

```mermaid
flowchart LR
    Operator((System Operator))
    ESP32((ESP32 Microcontroller))
    
    subgraph MicrogridSystem ["Solar Microgrid Management System"]
        UC1["UC-1: Connect Hardware Serial Port"]
        UC2["UC-2: Stream Live Sensor Telemetry"]
        UC3["UC-3: Run Offline Simulator Mode"]
        UC4["UC-4: Log Data to CSV File"]
        UC5["UC-5: Train Machine Learning Model"]
        UC6["UC-6: Forecast Available Solar Power"]
        UC7["UC-7: Configure DC Load Demand"]
        UC8["UC-8: Evaluate Solar Sufficiency"]
        UC9["UC-9: Inspect & Download Datasets"]
        UC10["UC-10: Monitor Thermal & Electrical Alarms"]
    end
    
    Operator --> UC1
    Operator --> UC3
    Operator --> UC5
    Operator --> UC6
    Operator --> UC7
    Operator --> UC8
    Operator --> UC9
    Operator --> UC10
    
    ESP32 --> UC2
    UC2 --> UC4
```

---

## 4. Class Diagram

```mermaid
classDiagram
    class SerialSensorReader {
        +String port
        +int baud_rate
        +float timeout
        +bool is_connected
        +String last_error
        +connect() bool
        +disconnect() void
        +read_reading() Dict
        -_validate_and_sanitize(raw: Dict) Dict
    }

    class SimulatorSensorReader {
        +float panel_rated_watts
        +float base_temp_c
        +float cum_energy_wh
        +read_reading() Dict
    }

    class CSVLogger {
        +Path target_filepath
        +String last_logged_timestamp
        -_ensure_file_initialized() void
        +append_reading(reading: Dict) bool
        +append_batch(readings: List) int
        +get_record_count() int
        +load_dataframe(max_rows: int) DataFrame
    }

    class DataProcessor {
        +clean_and_prepare_timeseries(df: DataFrame) DataFrame
        +compute_cumulative_energy_wh(df: DataFrame) DataFrame
        +compute_daily_summary(df: DataFrame) DataFrame
        +get_system_kpis(df: DataFrame, default_load_w: float) Dict
    }

    class SolarPowerPredictor {
        +Path model_path
        +Path metrics_path
        +bool is_loaded
        +Dict metadata
        +predict_from_record(lux, temp, humidity, dt) Dict
        +predict_dataframe(df: DataFrame) DataFrame
    }

    class EnergyManager {
        +float load_power_w
        +estimate_battery_soc(voltage_v: float) float
        +evaluate_energy_balance(solar_w, load_w, batt_v, has_cc) Dict
    }

    SerialSensorReader --> CSVLogger : streams to
    SimulatorSensorReader --> CSVLogger : streams to
    CSVLogger --> DataProcessor : provides data to
    DataProcessor --> EnergyManager : provides generation KPIs to
    SolarPowerPredictor --> EnergyManager : provides forecasts to
```

---

## 5. Sequence Diagram: Real-Time Sensing to Dashboard Workflow

```mermaid
sequenceDiagram
    autonumber
    actor Operator as Operator / User
    participant MCU as ESP32 Hardware
    participant Serial as SerialSensorReader
    participant Logger as CSVLogger
    participant Proc as DataProcessor
    participant ML as SolarPowerPredictor
    participant Engine as EnergyManager
    participant UI as Streamlit Dashboard

    Operator->>UI: Select COM Port & Click 'Connect'
    UI->>Serial: connect()
    Serial-->>UI: is_connected = True
    
    loop Every 1000 ms
        MCU->>MCU: Read DHT22, BH1750, INA219
        MCU->>Serial: Transmit JSON Lines over USB
        Serial->>Serial: _validate_and_sanitize()
        Serial->>Logger: append_reading(record)
        Logger->>Logger: Deduplicate & Flush to CSV
        
        UI->>Proc: get_system_kpis(df)
        Proc-->>UI: Return Power, Wh, Lux, Temp
        
        UI->>ML: predict_from_record(lux, temp, humidity)
        ML-->>UI: Return Predicted Power (W)
        
        UI->>Engine: evaluate_energy_balance(power, load)
        Engine-->>UI: Return Status (SOLAR_SUFFICIENT / INSUFFICIENT)
        
        UI-->>Operator: Render Real-Time Gauges, Graphs & Recommendations
    end
```

