# Project Overview: AI-Based Solar Microgrid Management System

**Degree:** Bachelor of Engineering in Computer Science & Engineering (BE CSE)  
**Project Category:** IoT, Machine Learning, Embedded Systems & Full-Stack Energy Management

---

## 1. Abstract
The intermittent nature of solar photovoltaic (PV) generation presents significant grid stabilization and load-matching challenges. This project implements a complete, cyber-physical **AI-Based Solar Microgrid Management System** using an **ESP32 microcontroller**, digital environmental and electrical sensors (DHT22, BH1750, INA219), a Python-driven telemetry ingestion engine, a machine learning forecasting model, and an interactive real-time dashboard.

Solar bus voltage, current, power, light illuminance, ambient temperature, and humidity are acquired at high frequency and streamed over USB Serial in structured JSON Lines format. A backend processing pipeline sanitizes incoming packets, prevents duplicate records, integrates cumulative energy in Watt-hours ($Wh$) via trapezoidal numerical approximation, and appends valid data to a live CSV dataset. A Random Forest regression model forecasts short-term power availability based on cyclical time encodings and environmental features. An energy management logic engine dynamically evaluates generation against configured DC load demands, indicating *Solar Sufficient* or *Solar Insufficient* states and providing battery storage recommendations under rigorous hardware safety constraints.

---

## 2. Problem Statement
Small-scale solar installations and educational microgrids frequently suffer from:
1. **Lack of Real-Time Visibility:** Absence of granular voltage, current, and irradiance telemetry makes it difficult for operators to understand real-time generation dynamics.
2. **Unpredictable Weather Fluctuations:** Sudden cloud transients cause generation to plunge without warning, leading to load brownouts.
3. **Hazardous Battery Management:** Beginners often connect lithium-ion cells directly to unregulated solar panels without understanding thermal runaway or overcharge risks.
4. **Data Fragmentation:** Absence of automated, structured data logging limits historical analysis and machine learning research.

---

## 3. Project Objectives
1. **Hardware Telemetry Integration:** Interfacing ESP32 with DHT22 (temp/humidity), BH1750 (lux), and INA219 (voltage/current/power) using standard I2C and single-bus protocols.
2. **Reliable Data Acquisition:** Developing a resilient Python serial reader that auto-detects ports, validates JSON lines, flags anomalies, and logs cleanly to CSV.
3. **Analytical Energy Accounting:** Implementing continuous numerical trapezoidal integration to compute energy yield ($Wh$ and $kWh$).
4. **Machine Learning Solar Forecasting:** Training a Random Forest Regressor using chronological splits to forecast short-term solar power availability.
5. **Intelligent Load Balancing & Advisory:** Dynamically evaluating solar sufficiency against a configurable load requirement and generating battery storage advice.
6. **Full-Stack Visualization:** Presenting real-time streaming charts, gauges, KPI cards, and dataset exploration tools in a 9-view Streamlit application.

---

## 4. Existing System vs. Proposed System

| Feature / Dimension | Existing Traditional Setup | Proposed AI Microgrid System |
| :--- | :--- | :--- |
| **Data Acquisition** | Manual analog multimeter readings or proprietary closed loggers | Automated, multi-sensor IoT telemetry via ESP32 streamed at 1 Hz |
| **Telemetry Format** | Unstructured text or proprietary binary | Human-readable, structured JSON Lines format |
| **Storage** | Manual spreadsheets or lost on reboot | Automated, thread-safe, deduplicated CSV datasets (`solar_dataset_live.csv`) |
| **Energy Calculation** | Rough estimation ($P \times \text{hours}$) | Continuous trapezoidal numerical integration ($E = \int P(t) dt$) |
| **Predictive Capability** | None (purely reactive) | Machine Learning regression (Random Forest) forecasting available power |
| **Microgrid Decision** | Manual operator switching | Automated software decision engine evaluating Solar Sufficiency |
| **Hardware Safety** | Often ignored or undocumented | Rigorous electrical bounds checking, thermal alarms, and battery protection policies |
| **Simulation Mode** | None (hardware required to test) | Grounded physics-based diurnal simulation mode for offline bench testing |

