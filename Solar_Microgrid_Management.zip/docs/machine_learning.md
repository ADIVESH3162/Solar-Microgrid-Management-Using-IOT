# Machine Learning Methodology: Solar Power Forecasting

## 1. Problem Formulation
Photovoltaic power generation is highly intermittent due to solar geometric position, cloud cover transients, and ambient temperature derating. The objective of the machine learning module is to perform **short-term regression forecasting** of available solar power ($P_{solar}$ in Watts) using real-time atmospheric measurements and cyclical temporal encodings.

---

## 2. Feature Engineering Pipeline

Solar radiation follows a daily periodic pattern. Feeding raw timestamps (e.g., hours 0 to 23) introduces artificial discontinuities between 23:59 and 00:00. To represent temporal cycles continuously, trigonometric cyclical encoding is applied:

$$h_{sin} = \sin\left(\frac{2\pi \cdot (hour + minute/60)}{24}\right)$$
$$h_{cos} = \cos\left(\frac{2\pi \cdot (hour + minute/60)}{24}\right)$$

### Complete Feature Set:
| Feature Name | Description | Rationale |
| :--- | :--- | :--- |
| `light_lux` | Instantaneous illuminance (lux) from BH1750 | Primary driver of photovoltaic generation ($P \propto \text{lux}$) |
| `temperature_c` | Ambient temperature (°C) from DHT22 | Captures negative thermal efficiency coefficient derating |
| `humidity_pct` | Relative humidity (%) from DHT22 | Correlates with atmospheric water vapor and diffuse scattering |
| `hour` | Hour of the day (0–23) | Diurnal positioning |
| `minute` | Minute of the hour (0–59) | Sub-hourly granularity |
| `hour_sin` | Sine-transformed time | Cyclical continuity across midnight |
| `hour_cos` | Cosine-transformed time | Orthogonal cyclical temporal coordinate |
| `lux_lag_1` | Previous period illuminance ($L_{t-1}$) | Short-term inertia and cloud persistence |
| `lux_rolling_3` | 3-sample moving average of lux | Smooths transient sensor jitter |
| `temp_rolling_3` | 3-sample moving average of temperature | Thermal inertia of the solar panel module |

---

## 3. Algorithm Selection: Random Forest Regressor

We selected **Random Forest Regression** over simple linear models or neural networks for the following engineering reasons:
1. **Non-Linear Photovoltaic Characteristics:** PV cells exhibit non-linear knee curves (I-V and P-V relationships) and thresholding behaviors (e.g., zero generation below diode forward bias threshold).
2. **Robustness to Multicollinearity:** Sensor features like temperature and light are correlated; tree-based ensembles handle correlated variables without numerical instability.
3. **Resistance to Overfitting:** Bootstrap aggregation (bagging) and random feature subsampling across 100 decision trees reduce prediction variance.
4. **Computational Efficiency:** Fast training and sub-millisecond inference on low-power host machines without requiring GPU acceleration.

---

## 4. Chronological Train/Test Splitting (Preventing Data Leakage)

> [!IMPORTANT]
> **Why Chronological Splitting is Mandatory:**
> Standard $k$-fold cross-validation or random shuffling (`train_test_split(shuffle=True)`) is fundamentally invalid for time-series forecasting. Shuffling introduces **lookahead leakage**, where the model trains on future samples to predict past samples, creating artificially inflated accuracy metrics.
> 
> Our pipeline uses an **80/20 chronological split**:
> - **Training Set:** The earliest 80% of contiguous records.
> - **Testing Set:** The remaining subsequent 20% of contiguous records.

---

## 5. Evaluation Metrics

Model accuracy is evaluated using three standard regression metrics:
1. **Mean Absolute Error (MAE):**
   $$\text{MAE} = \frac{1}{n}\sum_{i=1}^{n} |y_i - \hat{y}_i|$$
2. **Root Mean Squared Error (RMSE):**
   $$\text{RMSE} = \sqrt{\frac{1}{n}\sum_{i=1}^{n} (y_i - \hat{y}_i)^2}$$
3. **Coefficient of Determination ($R^2$ Score):**
   $$R^2 = 1 - \frac{\sum_{i=1}^n (y_i - \hat{y}_i)^2}{\sum_{i=1}^n (y_i - \bar{y})^2}$$

---

## 6. Physical Nocturnal Post-Processing Constraint
During nighttime hours ($t < 05:00$ or $t > 19:00$) or when measured illuminance drops below $5.0\text{ lx}$, unconstrained regressors can occasionally predict small non-zero power values (e.g., $0.02\text{ W}$). Our inference pipeline enforces a **hard physical constraint zeroing power output** whenever darkness is detected.

---

## 7. Model Provenance & Academic Honesty
When trained on `solar_dataset_historical.csv`, the model metadata records `is_synthetic_demonstration = True`. In accordance with engineering integrity principles, reported baseline metrics ($MAE \approx 0.01\text{ W}$, $R^2 \approx 0.99$) reflect performance on physics-generated simulation data. Once live hardware is deployed over several days, running `train_model.bat` retrains the model on genuine field telemetry.

