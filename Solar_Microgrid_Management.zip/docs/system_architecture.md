# System Architecture: AI-Based Solar Microgrid Management System

## 1. Multi-Tier Architectural Model

The system follows a modular, five-layer cyber-physical architecture:

```
+-----------------------------------------------------------------------+
|                       PRESENTATION LAYER (UI)                         |
|   Streamlit 9-View Dashboard  |  Plotly Visualizations  |  KPI Cards   |
+-----------------------------------------------------------------------+
                                   ▲
                                   │ DataFrames / System State / Metrics
+-----------------------------------------------------------------------+
|                    APPLICATION & DECISION LAYER                       |
|   EnergyManager Engine  |  Alerts Engine  |  SolarPowerPredictor      |
+-----------------------------------------------------------------------+
                                   ▲
                                   │ Feature Vectors / Numerical Aggregates
+-----------------------------------------------------------------------+
|                 ANALYTICS & MACHINE LEARNING LAYER                    |
|   DataProcessor (Wh)   |  FeatureEngineering  |  Random Forest Reg.   |
+-----------------------------------------------------------------------+
                                   ▲
                                   │ Cleaned Datasets / Streaming Dicts
+-----------------------------------------------------------------------+
|                  INGESTION & DATA LOGGING LAYER                       |
|   SerialSensorReader   |  CSVLogger  |  SimulatorSensorReader (Demo)  |
+-----------------------------------------------------------------------+
                                   ▲
                                   │ JSON Lines over USB Serial (115200)
+-----------------------------------------------------------------------+
|                   EMBEDDED HARDWARE SENSING LAYER                     |
|   ESP32 DevKit   |   DHT22 (GPIO4)   |   BH1750 & INA219 (I2C 21/22)  |
+-----------------------------------------------------------------------+
```

---

## 2. Layer-by-Layer Functional Breakdown

### A. Embedded Hardware Sensing Layer
- **ESP32 MCU:** Collects environmental and electrical measurements every 1000 ms using a non-blocking `millis()` timer.
- **DHT22 (AM2302):** Connects to GPIO4 using single-wire proprietary protocol to sample ambient temperature ($-40^\circ\text{C}$ to $80^\circ\text{C}$) and relative humidity ($0\%$ to $100\%$).
- **BH1750:** Connects to hardware I2C bus (SDA: GPIO21, SCL: GPIO22) at address `0x23` to sample illuminance ($0$ to $65,535\text{ lx}$).
- **INA219:** Connects to the same I2C bus at address `0x40` across an onboard $0.1\,\Omega$ shunt resistor, sampling solar bus voltage ($0$ to $26\text{ V}$), current ($0$ to $3.2\text{ A}$), and calculated power ($P=V \times I$).
- **Telemetry Transmission:** Serializes sanitized readings into a newline-delimited JSON string:
  ```json
  {"temp": 28.4, "humidity": 55.2, "lux": 45200.0, "voltage": 14.85, "current_ma": 420.5, "power_w": 6.244, "status": "OK"}
  ```

### B. Ingestion & Data Logging Layer (`src/sensor_serial.py`, `src/csv_logger.py`)
- **Port Discovery:** Enumerates Windows COM ports, identifying silicon bridges (CP2102, CH340, FTDI).
- **Packet Sanitization:** Parses incoming JSON strings; bounds-checks voltages, currents, temperatures; converts anomalies to `None`.
- **Thread-Safe Logging:** Flushes validated frames to `data/solar_dataset_live.csv`, strictly adhering to canonical column ordering and deduplicating timestamps.
- **Simulator Mode:** When hardware is detached, generates diurnal solar cycles with atmospheric cloud transients, tagging frames as `SIMULATED_DEMO`.

### C. Analytics & Machine Learning Layer (`src/data_processor.py`, `src/feature_engineering.py`, `src/train_model.py`)
- **Trapezoidal Energy Integration:** Numerically computes cumulative energy in Watt-hours ($Wh$).
- **Feature Engineering:** Derives cyclic hour sinusoids ($\sin(2\pi \cdot t/24)$, $\cos(2\pi \cdot t/24)$), lag variables ($L_{t-1}$), and rolling averages.
- **Random Forest Regressor:** An ensemble of decision trees trained with chronological train/test splitting ($80/20\%$) to forecast power without time-leakage.
- **Provenance Tracking:** Records whether model was trained on genuine hardware or synthetic baseline datasets.

### D. Application & Decision Layer (`src/energy_management.py`, `src/alerts.py`)
- **Microgrid Balance Engine:** Computes instantaneous net power $P_{net} = P_{solar} - P_{load}$.
- **Sufficiency Classification:** Assigns microgrid states (`SOLAR_SUFFICIENT`, `SOLAR_INSUFFICIENT`, `INSUFFICIENT_DATA`).
- **Battery Advisory:** Estimates 18650 SoC ($0-100\%$) based on open-circuit voltage; advises charging only when a certified solar charge controller is verified.
- **Anomaly Alarms:** Continuously scans telemetry for overvoltage ($>25\text{ V}$), overcurrent ($>2.5\text{ A}$), and thermal thresholds ($>60^\circ\text{C}$).

### E. Presentation Layer (`app.py`)
- Full-stack Streamlit dashboard with 9 dedicated views.
- Real-time Plotly streaming charts, gauge dials, historical analytics, dataset inspection tables, and download utilities.

