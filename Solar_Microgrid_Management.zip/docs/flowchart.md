# System Flowcharts

This document provides visual flowcharts using Mermaid syntax illustrating the operational workflows of the microgrid system.

---

## 1. ESP32 Firmware Main Execution Loop

```mermaid
flowchart TD
    Start([ESP32 Power On / Reset]) --> InitSerial[Initialize Serial at 115200 baud]
    InitSerial --> InitI2C[Initialize I2C Wire on GPIO21 SDA & GPIO22 SCL]
    InitI2C --> InitDHT[Initialize DHT22 on GPIO4]
    InitDHT --> InitBH[Initialize BH1750 on Addr 0x23]
    InitBH --> InitINA[Initialize INA219 on Addr 0x40 & Set 32V/2A Calibration]
    InitINA --> EmitInit[Send JSON Startup Event: INIT]
    EmitInit --> LoopStart{Elapsed Time >= 1000ms?}
    
    LoopStart -- No --> LoopStart
    LoopStart -- Yes --> ReadDHT[Read DHT22: Temperature & Humidity]
    ReadDHT --> ReadBH[Read BH1750: Ambient Light in Lux]
    ReadBH --> ReadINA[Read INA219: Bus Voltage, Current & Power]
    ReadINA --> CheckFaults{Any Sensor Error?}
    
    CheckFaults -- Yes --> MarkStatus[Set field to NULL & Append Sensor Error Flag]
    CheckFaults -- No --> SetOk[Set Status = OK]
    
    MarkStatus --> BuildJSON[Construct JSON Document]
    SetOk --> BuildJSON
    BuildJSON --> TransmitSerial[Transmit Newline-Delimited JSON over Serial]
    TransmitSerial --> BlinkLED[Blink Status LED GPIO2]
    BlinkLED --> LoopStart
```

---

## 2. Python Serial Telemetry Ingestion & CSV Logging Workflow

```mermaid
flowchart TD
    StartHost([Host Application Launch]) --> DetectPort[Enumerate COM Ports: Search for CP210x, CH340]
    DetectPort --> PortFound{Port Found?}
    
    PortFound -- Yes --> OpenSerial[Open Serial Connection at 115200 Baud]
    PortFound -- No --> EnableSim[Prompt Connection or Enable Simulator Mode]
    
    OpenSerial --> ReadStream[Read Serial Line from Stream]
    ReadStream --> CheckLine{Valid JSON Line?}
    
    CheckLine -- No --> DropPacket[Drop Corrupted Packet / Skip]
    DropPacket --> ReadStream
    
    CheckLine -- Yes --> ParseJSON[Parse JSON & Validate Physical Bounds]
    ParseJSON --> CheckDup{Timestamp Duplicate?}
    
    CheckDup -- Yes --> SkipDup[Ignore Duplicate Row]
    SkipDup --> ReadStream
    
    CheckDup -- No --> AppendCSV[Append Validated Row to data/solar_dataset_live.csv]
    AppendCSV --> ComputeEnergy[Calculate Trapezoidal Energy Wh]
    ComputeEnergy --> CheckAlarms[Evaluate Electrical & Thermal Thresholds]
    CheckAlarms --> UpdateUI[Update Streamlit Dashboard Gauges & Charts]
    UpdateUI --> ReadStream
```

---

## 3. Machine Learning Training Pipeline

```mermaid
flowchart TD
    StartML([Initiate Model Training]) --> LoadCSV[Load data/solar_dataset_historical.csv]
    LoadCSV --> CheckProv{Check Data Source Provenance}
    
    CheckProv --> TagProv[Record is_synthetic_demonstration Flag]
    TagProv --> CleanData[Clean Data & Parse Timestamps]
    CleanData --> FeatureEng[Feature Engineering: Hour, Minute, Sin/Cos Encoded Time, Lags, Rolling Means]
    FeatureEng --> ChronoSplit[Chronological Split: 80% Train, 20% Test]
    
    ChronoSplit --> TrainRF[Fit RandomForestRegressor: 100 Estimators, Max Depth 12]
    TrainRF --> PredictTest[Predict on Test Horizon]
    PredictTest --> EnforceNight[Zero Predictions for Lux <= 5.0]
    
    EnforceNight --> ComputeMetrics[Compute Evaluation Metrics: MAE, RMSE, R² Score]
    ComputeMetrics --> SaveModel[Serialize Model to models/solar_power_rf_model.joblib]
    SaveModel --> SaveMeta[Write Metadata & Provenance to models/model_metrics.json]
    SaveMeta --> EndML([Training Complete])
```

---

## 4. Energy Management & Microgrid Dispatch Logic

```mermaid
flowchart TD
    StartEM([Telemetry Received]) --> CheckData{Solar Power Valid?}
    
    CheckData -- No --> StateUnknown[Set State: INSUFFICIENT_DATA]
    StateUnknown --> EndEM([Await Telemetry])
    
    CheckData -- Yes --> CompareLoad{Solar Power >= Configured Load Demand?}
    
    CompareLoad -- Yes --> StateSufficient[Set State: SOLAR_SUFFICIENT]
    StateSufficient --> CalcSurplus[Calculate Surplus Power = P_solar - P_load]
    CalcSurplus --> CheckCC{Solar Charge Controller Verified?}
    CheckCC -- Yes --> AdviceStore[Advisory: Store Surplus in Battery via CC/CV Controller]
    CheckCC -- No --> AdviceHold[Advisory: Surplus Available; Battery Storing Prohibited without Charge Controller]
    
    CompareLoad -- No --> StateInsufficient[Set State: SOLAR_INSUFFICIENT]
    StateInsufficient --> CalcDeficit[Calculate Deficit Power = P_load - P_solar]
    CalcDeficit --> CheckBatt{Battery SoC > 20%?}
    CheckBatt -- Yes --> AdviceDischarge[Advisory: Supplement Deficit from Battery Reserve]
    CheckBatt -- No --> AdviceShed[Advisory: CRITICAL - Low Battery. Shed Non-Critical Loads]
    
    AdviceStore --> EndEM
    AdviceHold --> EndEM
    AdviceDischarge --> EndEM
    AdviceShed --> EndEM
```

