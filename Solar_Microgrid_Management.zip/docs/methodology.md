# Engineering Methodology & Implementation Phases

The project was executed through an iterative, scientific engineering methodology comprising five core phases:

---

## Phase 1: Hardware Bench Circuit Design & Safety Engineering
1. **Sensor Bus Topology:**
   - Evaluated the ESP32 hardware peripheral capabilities. Selected hardware I2C bus on **GPIO21 (SDA)** and **GPIO22 (SCL)**, allowing BH1750 (address `0x23`) and INA219 (address `0x40`) to share the bus without pin contention.
   - Assigned dedicated single-wire timing pin **GPIO4** to DHT22 to avoid interrupt latency issues.
2. **Electrical Safety Rules:**
   - Established strict DC isolation: ESP32 powered strictly via regulated USB 5.0V from the host PC.
   - Prohibited raw direct connections between 18650 lithium cells and solar panels. Solar panels generate up to $21\text{ V}$ open-circuit, which destroys 4.2V lithium cells without a regulated CC/CV charge controller.
   - Designed high-side current measurement using the INA219 $0.1\,\Omega$ shunt between solar positive and load positive, maintaining common ground reference.

---

## Phase 2: Firmware Architecture & Robust Serial Telemetry
1. **Non-Blocking Sampling:**
   - Implemented a 1000 ms timer using Arduino `millis()` rather than blocking `delay()`, ensuring the microcontroller remains responsive.
2. **Fault-Tolerant Sensor Probing:**
   - Implemented sensor initialization health checks. When a sensor is detached or experiences an I2C timeout, the firmware does not crash or emit bogus numbers; it assigns `null` to the corresponding JSON key and appends an error code (e.g., `DHT_ERR`, `INA219_ERR`).
3. **Structured Protocol:**
   - Formatted all serial frames as JSON Lines (newline-delimited JSON) at 115200 baud, enabling standard stream parsers on the host.

---

## Phase 3: Telemetry Ingestion, Data Integrity & Numerical Integration
1. **Host-Side Port Discovery:**
   - Developed auto-detection heuristics scanning Windows COM ports for known USB-UART chips (CP2102, CH340, FTDI).
2. **Deduplication & Schema Enforcement:**
   - Implemented atomic CSV appending in `CSVLogger` with duplicate timestamp rejection to prevent UI refreshes from inflating data volume.
3. **Mathematical Energy Modeling:**
   - Applied the trapezoidal numerical integration rule over power $P(t)$:
     $$E(T) = \sum_{i=1}^{N} \frac{P(t_i) + P(t_{i-1})}{2} \times \frac{\Delta t_i}{3600}$$
   - Capped $\Delta t_i$ at 300 seconds to eliminate erroneous energy jumps across long system downtimes.

---

## Phase 4: Machine Learning Power Forecasting Pipeline
1. **Chronological Splitting:**
   - Avoided standard random train/test splitting (k-fold shuffle) because solar generation exhibits strong temporal auto-correlation. Applied chronological splitting ($80\%$ train on older data, $20\%$ test on subsequent days) to eliminate lookahead bias.
2. **Cyclical Feature Transformation:**
   - Transformed hour of day into sine and cosine orthogonal projections:
     $$h_{sin} = \sin\left(\frac{2\pi \cdot t}{24}\right), \quad h_{cos} = \cos\left(\frac{2\pi \cdot t}{24}\right)$$
3. **Random Forest Regression:**
   - Trained an ensemble of 100 decision trees to capture non-linear relationships between light intensity, atmospheric temperature, and electrical power output.
4. **Physical Bounds Enforcement:**
   - Zeroed predicted power during night hours (irradiance $\le 5\text{ lx}$) to prevent non-physical nocturnal generation predictions.

---

## Phase 5: Microgrid Energy Management & Full-Stack Dashboard
1. **Decision Engine:**
   - Compared real-time or forecasted generation against a user-configurable DC load requirement (default 5.0 W). Classified operating conditions into `SOLAR_SUFFICIENT` and `SOLAR_INSUFFICIENT`.
2. **Advisory Battery Control:**
   - Evaluated 18650 State of Charge using an open-circuit voltage discharge curve. Enforced advisory-only mode until physical relay/MOSFET hardware is confirmed.
3. **Interactive Dashboard:**
   - Built a 9-view Streamlit application featuring live gauges, historical multi-parameter trends, dataset exploration, and diagnostic monitoring.

