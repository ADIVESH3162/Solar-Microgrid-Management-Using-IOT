# Hardware Limitations & Future Roadmap

## 1. Current System Scope & Hardware Limitations

This project is built as a complete, safe, and academically rigorous final-year capstone system. In keeping with sound engineering practice, the following limitations are explicitly documented:

### A. Advisory vs. Physical Actuation
- **Current Capability:** The system computes microgrid balance ($P_{net} = P_{solar} - P_{load}$), classifies solar sufficiency, and provides optimal dispatch recommendations in software.
- **Limitation:** The current bench hardware setup does not include physical relay switches or power MOSFETs to automatically disconnect loads or engage battery banks.
- **Rationale:** Automatic high-current switching on breadboard circuits without optocoupler isolation, flyback diodes, and snubbers introduces fire, contact arcing, and ESP32 reboot risks.

### B. Battery Charging Constraints
- **Current Capability:** The software monitors battery voltage (when a sensor is connected) and estimates State of Charge (SoC) using an Open-Circuit Voltage curve.
- **Limitation:** The system does NOT directly charge the 18650 lithium battery from the solar panel.
- **Safety Grounding:** Connecting a bare 18650 cell directly to a solar panel causes catastrophic overcharging and thermal runaway. A dedicated charge controller (e.g., TP4056 with DW01A protection IC or an MPPT charge controller) is mandatory before physical energy storage can be engaged.

### C. INA219 Sensing Boundaries
- **Maximum Voltage:** The INA219 IC has a maximum bus voltage rating of **26.0 V DC**. It cannot be connected to high-voltage residential solar strings (100V–600V).
- **Maximum Current:** The standard $0.1\,\Omega$ shunt resistor supports up to **3.2 A DC**. Currents exceeding this rating will saturate the amplifier or overheat the shunt.

### D. Single-Point Light Measurement
- The BH1750 provides planar illuminance (lux) at a single orientation. In large-scale PV plants, pyranometers measure Global Horizontal Irradiance (GHI) and Plane of Array (POA) irradiance in $W/m^2$.

---

## 2. Future Hardware & Software Roadmap

| Future Enhancement | Additional Hardware / Software Required | Engineering Benefit |
| :--- | :--- | :--- |
| **Physical Load Shedding** | 5V Optocoupled Relay Module or Logic-Level Power MOSFETs (IRLZ44N) | Automatically isolates non-critical DC circuits during solar deficits |
| **Integrated Battery Charging** | TP4056 CC/CV Module + 1S BMS or Solar MPPT Buck Controller | Safely routes surplus solar energy to the 18650 cell with cutoff protection |
| **Wireless IoT Cloud Uplink** | ESP32 Wi-Fi / MQTT Protocol (AWS IoT Core or Mosquitto) | Enables remote multi-site telemetry without requiring USB tethering |
| **Deep Learning Time-Series** | LSTM / GRU / Temporal Convolutional Networks | Captures multi-hour cloud trajectory memory across changing seasons |
| **Dual-Axis Solar Tracker** | 2x SG90 Servo Motors + 4x LDR Sensors | Physically orients solar panel normal to the sun, increasing yield by $25\text{--}35\%$ |
| **Inverter AC Integration** | Small pure-sine DC-to-AC Inverter + ZMPT101B Voltage Transformer | Enables powering 230V AC household appliances |

