# 30+ Comprehensive Viva Voce Questions & Answers

**Project Title:** AI-Based Solar Microgrid Management System Using IoT, Real-Time Sensor Data, CSV Dataset and Machine Learning  
**Target Audience:** Final-Year BE Computer Science & Engineering (CSE) Examination & Project Defense

---

## Category 1: Embedded Systems & IoT (ESP32 & Sensors)

### Q1: Why did you choose the ESP32 microcontroller over an Arduino Uno?
**Answer:** The ESP32 is a 32-bit dual-core Tensilica Xtensa processor running at up to 240 MHz with 520 KB SRAM, compared to the Arduino Uno's 8-bit ATmega328P running at 16 MHz with 2 KB SRAM. The ESP32 features multiple hardware I2C and UART buses, high-precision ADC, non-blocking timers, and built-in Wi-Fi/Bluetooth capabilities for future wireless scaling.

### Q2: What communication protocol is used between the ESP32 and the sensors?
**Answer:**
- **BH1750 and INA219:** Use the **I2C (Inter-Integrated Circuit)** synchronous, multi-device bus protocol over two lines: **SDA (GPIO21)** for data and **SCL (GPIO22)** for clock.
- **DHT22:** Uses a proprietary **Single-Bus (One-Wire style)** asynchronous serial protocol over **GPIO4**, which exchanges timing-critical high/low pulses to transmit 40 bits of temperature and humidity data.
- **Host PC Link:** Uses **Universal Asynchronous Receiver-Transmitter (UART / USB Serial)** at 115200 baud.

### Q3: How do BH1750 and INA219 share the same I2C pins without data collisions?
**Answer:** I2C is an addressable bus protocol. Each peripheral device responds to a unique 7-bit slave address:
- The BH1750 defaults to address `0x23` (when its ADDR pin is pulled low or floating).
- The INA219 defaults to address `0x40` (when A0 and A1 pins are grounded).  
The ESP32 acts as the I2C master. Before transmitting or requesting data, it broadcasts the target device's address. Only the device matching that address acknowledges (ACK), completely preventing bus collision.

### Q4: What is high-side sensing, and why does the INA219 use it?
**Answer:** In high-side current sensing, the shunt resistor ($0.1\,\Omega$) is placed between the positive terminal of the power supply (solar panel positive) and the positive terminal of the load. This is superior to low-side sensing (measuring between load negative and ground) because it keeps the load ground directly connected to the system ground, preventing ground loop offsets and allowing detection of short-circuits to ground.

### Q5: How does the INA219 calculate current and power?
**Answer:** The INA219 contains an internal 12-bit programmable analog-to-digital converter (PGA/ADC) that measures the minute voltage drop across its $0.1\,\Omega$ shunt resistor:
$$I = \frac{V_{shunt}}{R_{shunt}} = \frac{V_{shunt}}{0.1\,\Omega}$$
It also measures the bus voltage ($V_{bus}$) at the `VIN-` pin relative to ground. Power is calculated digitally inside the sensor:
$$P = V_{bus} \times I$$

### Q6: Why did you choose JSON Lines format for serial transmission instead of raw CSV strings?
**Answer:** Raw comma-separated strings over serial are brittle; if a single character drops or a sensor fails, column positions shift silently. JSON Lines (`{"temp": 28.5, "lux": 45000, ...}\n`) provides:
1. Self-describing key-value schemas.
2. Explicit `null` handling when a sensor fails, preventing incorrect column alignments.
3. Clean error and status reporting (e.g., `"status": "DHT_ERR"`).
4. Atomic line-by-line parsing using standard JSON libraries.

---

## Category 2: Machine Learning & Predictive Modeling

### Q7: What regression algorithm is implemented, and why?
**Answer:** We implemented a **Random Forest Regressor** (`scikit-learn`). Random Forest is an ensemble learning method constructed of multiple decision trees ($n_{estimators} = 100$) trained on bootstrap samples with random feature selection. It handles non-linear relationships between light intensity, atmospheric temperature, and photovoltaic output without making rigid assumptions about data distributions, and it is highly resistant to overfitting compared to single decision trees.

### Q8: Why is standard k-fold cross-validation or random train_test_split WRONG for solar prediction?
**Answer:** Solar generation data is a time-series with strong chronological auto-correlation. Shuffling data randomly (`train_test_split(shuffle=True)`) creates **data leakage / lookahead bias**, where the model learns from future data points to predict past points. In real-world operation, the model only has access to past historical records. Therefore, a strict **chronological split** (first 80% for training, subsequent 20% for testing) is mandatory.

### Q9: Why did you apply cyclical sine/cosine encoding to the time feature?
**Answer:** Standard linear hour numbers treat 23:59 (hour 23) and 00:01 (hour 0) as having a numerical distance of 23 units, when physically they are only two minutes apart. By mapping the hour fraction into polar coordinates:
$$\text{hour\_sin} = \sin\left(\frac{2\pi \cdot t}{24}\right), \quad \text{hour\_cos} = \cos\left(\frac{2\pi \cdot t}{24}\right)$$
the continuous cyclical nature of the 24-hour day is preserved without artificial mathematical boundaries.

### Q10: How do you prevent the model from predicting solar power at night?
**Answer:** While tree-based regressors generally output low numbers at night, noise can occasionally produce small positive outputs ($0.05\text{ W}$). Our inference pipeline enforces a **domain-specific physical constraint**: whenever measured light is $\le 5.0\text{ lx}$ or hour is outside daytime boundaries ($<05:00$ or $>19:00$), predicted power is clamped to exactly $0.0\text{ W}$.

### Q11: Explain the evaluation metrics MAE, RMSE, and $R^2$.
**Answer:**
- **Mean Absolute Error (MAE):** Average magnitude of errors in Watts ($\frac{1}{n}\sum |y - \hat{y}|$). Easy to interpret directly.
- **Root Mean Squared Error (RMSE):** Square root of the average squared errors ($\sqrt{\frac{1}{n}\sum (y - \hat{y})^2}$). Penalizes large prediction errors more severely than MAE.
- **$R^2$ Score (Coefficient of Determination):** Proportion of variance in actual solar power explained by the model ($1 - \frac{SS_{res}}{SS_{tot}}$). An $R^2$ of 1.0 indicates perfect explanation.

### Q12: What is the academic transparency/provenance policy of your model?
**Answer:** The system explicitly records whether training used live hardware measurements or baseline demonstration data. If trained on synthetic datasets (`solar_dataset_historical.csv`), the model metadata tags `is_synthetic_demonstration = True`. We never present synthetic demonstration metrics as physical hardware validation.

---

## Category 3: Electrical Engineering & Battery Safety

### Q13: Why is it dangerous to connect a bare 18650 lithium battery directly to a solar panel?
**Answer:** A typical small solar panel produces an open-circuit voltage ($V_{oc}$) of 18V to 21V. A single-cell 18650 lithium-ion battery has a nominal voltage of 3.7V and an absolute maximum charging cutoff voltage of **4.20V $\pm$ 0.05V**. Direct connection subjects the cell to severe overvoltage and uncontrolled charge current, which causes lithium plating on the anode, electrolyte decomposition, severe thermal runaway, venting, and fire or explosion.

### Q14: What hardware is required to safely connect an 18650 cell to a solar panel?
**Answer:**
1. A **DC-DC Step-Down (Buck) Converter** or MPPT controller to reduce panel voltage.
2. A **CC/CV Solar Charge Controller** (e.g., TP4056) to manage constant current (CC) and constant voltage (CV) stages.
3. A **Battery Management System (BMS)** (such as DW01A + 8205A MOSFETs) providing overcharge, over-discharge ($<3.0\text{V}$), and short-circuit protection.

### Q15: Why can't we connect the solar panel directly to the ESP32 3.3V pin?
**Answer:** The ESP32 operates at 3.3V CMOS logic. Its 3.3V pin is connected to the output of an onboard low-dropout (LDO) linear regulator designed to supply small currents to the chip. Applying external voltages above 3.6V directly to this rail bypasses protection and permanently destroys the silicon substrate.

### Q16: How do you estimate battery State of Charge (SoC) from voltage?
**Answer:** We implement an Open-Circuit Voltage (OCV) lookup curve for lithium-ion chemistry:
- $\ge 4.20\text{ V} \rightarrow 100\%$ (Fully Charged)
- $4.00\text{ V} \rightarrow 80\%$
- $3.82\text{ V} \rightarrow 50\%$ (Nominal Plateau)
- $3.65\text{ V} \rightarrow 20\%$ (Discharged Warning)
- $\le 3.00\text{ V} \rightarrow 0\%$ (Safe Cutoff Threshold)

---

## Category 4: Energy Management & Microgrid Logic

### Q17: What are the three microgrid operating states defined in your system?
**Answer:**
1. `SOLAR_SUFFICIENT`: Real-time solar power generation ($P_{solar}$) meets or exceeds the connected DC load demand ($P_{load}$). Surplus power ($P_{surplus} = P_{solar} - P_{load}$) is available.
2. `SOLAR_INSUFFICIENT`: Solar power generation is less than the load demand. Supplemental energy ($P_{deficit} = P_{load} - P_{solar}$) is required from storage or the utility grid.
3. `INSUFFICIENT_DATA`: Sensors are uninitialized, disconnected, or communication has timed out.

### Q18: How is cumulative energy calculated from instantaneous power readings?
**Answer:** Energy is the time-integral of power: $E = \int P(t) dt$. In discrete sampling, we apply the **trapezoidal numerical integration rule**:
$$E = \sum_{i=1}^{N} \frac{P_i + P_{i-1}}{2} \times \frac{\Delta t_i}{3600 \text{ s/hr}}$$
where $\Delta t$ is the elapsed seconds between consecutive readings, yielding energy directly in Watt-hours ($Wh$).

### Q19: Why does your trapezoidal integration cap $\Delta t$ at 300 seconds?
**Answer:** If the system is turned off overnight or disconnected for 8 hours and restarted, a naive integration would multiply the average power by 8 hours ($28,800\text{ s}$), creating a massive, erroneous jump in cumulative energy. Capping $\Delta t$ at 300 seconds (5 minutes) ensures that prolonged offline periods do not corrupt energy accounting.

---

## Category 5: Software Engineering & Data Architecture

### Q20: How does your CSV Logger prevent duplicate records during rapid Streamlit refreshes?
**Answer:** Streamlit reruns scripts from top to bottom on UI interactions. The `CSVLogger` class maintains a thread-safe cache of `last_logged_timestamp`. If an incoming record has an identical timestamp to the previous write, the logger rejects it, ensuring that UI re-renders do not bloat or corrupt `solar_dataset_live.csv`.

### Q21: What happens if the ESP32 is unplugged while the dashboard is running?
**Answer:** The `SerialSensorReader` catches `serial.SerialException` and `OSError` exceptions gracefully. It updates its internal status to `is_connected = False`, logs a warning, and switches the UI badge to `HARDWARE DISCONNECTED` without raising an unhandled exception or crashing the Streamlit server.

### Q22: What is the purpose of the Simulator Mode?
**Answer:** The `SimulatorSensorReader` implements a physics-grounded solar model that simulates diurnal sun angles, clear-sky irradiance, atmospheric cloud attenuation, and panel temperature derating. This allows full software testing, demonstration, and viva presentation even if hardware is unavailable or testing occurs indoors at night. Crucially, all simulated records are tagged as `SIMULATED_DEMO`.

### Q23: How do you validate datasets for integrity?
**Answer:** We created `scripts/validate_dataset.py`, which programmatically audits:
1. Column schema conformance against `CSV_COLUMNS`.
2. Timestamp monotonicity (strictly non-decreasing order).
3. Duplication counts.
4. Physical electrical consistency ($P \approx V \times I / 1000$ within $\pm 0.5\text{ W}$).
5. Range bounds ($0 \le V \le 26\text{ V}$, $0 \le I \le 3200\text{ mA}$, $-20 \le T \le 70\text{^\circ C}$).

### Q24: What is the role of the INA219 calibration register?
**Answer:** The INA219 has a internal calibration register that scales the raw voltage drop across the shunt resistor into physical current and power values based on the shunt resistance ($0.1\,\Omega$) and expected maximum current ($3.2\text{ A}$ for 32V/2A mode). Configuring this in firmware (`ina219.setCalibration_32V_2A()`) ensures calibrated readings without host-side scaling errors.

### Q25: Why is ambient temperature monitoring relevant for solar panels?
**Answer:** Silicon photovoltaic cells suffer from a **negative temperature coefficient of power** ($\gamma \approx -0.4\% / \text{^\circ C}$ above $25\text{^\circ C}$). As panels heat up in intense sunlight, their open-circuit voltage drops, reducing total electrical power output. Monitoring ambient temperature with the DHT22 provides essential context for explaining why power output may decrease on very hot days despite high illuminance.

### Q26: What are the key advantages of using Plotly over Matplotlib for this dashboard?
**Answer:** Matplotlib generates static raster/PNG images that require complete re-rendering and lack user interactivity. Plotly generates client-side HTML5/WebGL interactive vectors supporting zoom, pan, hover tooltips, and dynamic series toggling, essential for real-time telemetry streaming.

### Q27: How does your code maintain paths consistently across different operating systems?
**Answer:** We use Python's `pathlib.Path(__file__).resolve().parent` to dynamically anchor all file paths relative to the project root directory rather than relying on hardcoded Windows paths or working-directory assumptions.

### Q28: What is the purpose of the `.gitkeep` files in empty directories?
**Answer:** Git does not track empty directories by default. Placing `.gitkeep` in `models/`, `outputs/`, and `data/` ensures that the project directory structure is preserved when cloned or distributed.

### Q29: What are the primary features engineered for the Random Forest model?
**Answer:**
1. `light_lux`: Primary driver.
2. `temperature_c`: Thermal derating driver.
3. `humidity_pct`: Atmospheric attenuation proxy.
4. `hour` & `minute`: Linear diurnal time.
5. `hour_sin` & `hour_cos`: Cyclical diurnal projections.
6. `lux_lag_1`: Previous period illuminance.
7. `lux_rolling_3`: 3-sample smoothed illuminance.
8. `temp_rolling_3`: 3-sample smoothed temperature.

### Q30: How would you extend this project for industrial microgrid deployment?
**Answer:**
1. **Wireless Uplink:** Replace USB serial with MQTT over Wi-Fi/LTE connecting to AWS IoT Core or an edge broker.
2. **Physical Switching:** Interface logic-level MOSFETs or solid-state relays (SSRs) for automated load shedding.
3. **MPPT Tracking:** Add Perturb-and-Observe (P&O) maximum power point tracking hardware.
4. **Energy Storage:** Integrate a multi-cell LiFePO4 battery pack with an intelligent industrial BMS.

