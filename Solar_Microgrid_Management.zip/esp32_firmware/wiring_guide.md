# ESP32 Solar Microgrid Sensor Hardware Wiring Guide

## 1. System Overview & Safety Guidelines

> [!CAUTION]
> **CRITICAL ELECTRICAL SAFETY RULES:**
> 1. **Never connect a bare 18650 Lithium-ion cell directly to a solar panel.** A typical small solar panel generates 18V to 21V open-circuit (Voc), while a single 18650 cell has a strict charging limit of 4.2V. Direct connection will cause thermal runaway, cell rupture, or fire. A dedicated solar charge controller (or TP4056 with CC/CV protection and step-down) is strictly required for battery charging.
> 2. **Never connect a solar panel or 18650 battery directly to the ESP32 3.3V pin or GPIOs.** ESP32 GPIOs tolerate a maximum of 3.3V. Feeding higher DC voltage will permanently burn the microcontroller.
> 3. **Initially power the ESP32 exclusively from the laptop USB port.** The laptop USB port provides a clean, regulated 5.0V supply to the ESP32 onboard regulator.
> 4. **Common Ground:** The ESP32 GND, sensor GNDs, and the negative rail of the DC circuit must be tied together to ensure accurate reference voltages.

---

## 2. Complete Pin-to-Pin Wiring Table

| Component | Sensor Pin | ESP32 30-Pin Board | Voltage / Level | Purpose / Notes |
| :--- | :--- | :--- | :--- | :--- |
| **DHT22** | VCC (Pin 1) | 3.3V (or VIN/5V) | 3.3V DC | Sensor power |
| **DHT22** | DATA (Pin 2) | **GPIO 4** | 3.3V Logic | Single-bus data line (optional 10k pull-up to 3.3V) |
| **DHT22** | NC (Pin 3) | Not Connected | - | Leave disconnected |
| **DHT22** | GND (Pin 4) | GND | 0V | Ground reference |
| **BH1750** | VCC | 3.3V | 3.3V DC | Light sensor power |
| **BH1750** | GND | GND | 0V | Ground reference |
| **BH1750** | SCL | **GPIO 22** | 3.3V I2C Clock | Hardware I2C Clock (shared) |
| **BH1750** | SDA | **GPIO 21** | 3.3V I2C Data | Hardware I2C Data (shared) |
| **BH1750** | ADDR / ADD | GND | 0V | Sets I2C address to `0x23` (if left floating, defaults to `0x23`) |
| **INA219** | VCC | 3.3V (or 5V) | 3.3V DC | IC digital logic supply |
| **INA219** | GND | GND | 0V | Common Ground reference |
| **INA219** | SCL | **GPIO 22** | 3.3V I2C Clock | Hardware I2C Clock (shared) |
| **INA219** | SDA | **GPIO 21** | 3.3V I2C Data | Hardware I2C Data (shared) |
| **INA219** | **VIN+** | Solar Panel (+) | Up to 26V DC | High-side sensing: positive feed from solar source |
| **INA219** | **VIN-** | Load (+) | Up to 26V DC | High-side sensing: output to DC load |

---

## 3. High-Side Current & Power Sensing Diagram (INA219)

The INA219 features an onboard 0.1 $\Omega$ precision current shunt resistor between `VIN+` and `VIN-`.

```
[ Solar Panel (+) ] ------------> [ INA219: VIN+ ]
                                        | (0.1 Ohm Shunt)
[ DC Load (+) ]     <------------ [ INA219: VIN- ]

[ Solar Panel (-) ] ------------+
                                |
[ DC Load (-) ]     ------------+----> [ ESP32 GND / Common Ground ]
```

### Why High-Side Sensing?
Unlike low-side sensing (measuring on the negative wire), high-side sensing avoids disturbing the ground potential of your load. The load ground remains at genuine 0V reference.

---

## 4. Breadboard Assembly Step-by-Step

1. **Mount ESP32:** Insert the 30-pin ESP32 across the center divider of the breadboard so pins on each side are accessible.
2. **Establish Power Rails:**
   - Connect ESP32 `3.3V` pin to Breadboard Red (+) rail.
   - Connect ESP32 `GND` pin to Breadboard Blue/Black (-) rail.
3. **Wire I2C Sensors (BH1750 & INA219):**
   - Connect BH1750 `VCC` and INA219 `VCC` to the 3.3V rail.
   - Connect BH1750 `GND` and INA219 `GND` to the GND rail.
   - Connect BH1750 `SDA` and INA219 `SDA` together to ESP32 **GPIO 21**.
   - Connect BH1750 `SCL` and INA219 `SCL` together to ESP32 **GPIO 22**.
4. **Wire DHT22:**
   - Connect DHT22 Pin 1 (VCC) to 3.3V.
   - Connect DHT22 Pin 2 (DATA) to ESP32 **GPIO 4**. (Add a 10k resistor between Pin 1 and Pin 2 if your module lacks a built-in pull-up).
   - Connect DHT22 Pin 4 (GND) to GND rail.
5. **Circuit Measurement Test (Low-Voltage DC):**
   - Connect a small solar panel positive terminal to INA219 `VIN+`.
   - Connect a small test DC load (e.g. 5V USB bulb, small DC motor, or 100 $\Omega$ power resistor) to INA219 `VIN-`.
   - Connect the solar panel negative and the load negative to the common ground rail.
6. **Connect ESP32 USB to PC:** Plug the micro-USB cable into your laptop. Verify the red power LED is solid and the blue LED flashes during reading transmissions.

---

## 5. Safe Bench Testing Without Full Solar Setup

If testing indoors or at night:
- **Light source:** Use a desk lamp or smartphone flashlight to vary the BH1750 reading between 50 lx and 50,000 lx.
- **Electrical source:** A small 5V or 9V DC battery pack or bench power supply through a 100 $\Omega$ resistor into INA219 `VIN+` and `VIN-` will safely register voltage, current, and power.
- **Simulator Mode:** If hardware is not connected, the included Python system features an explicit **Simulator Mode** that generates physics-compliant solar curves without hardware!

