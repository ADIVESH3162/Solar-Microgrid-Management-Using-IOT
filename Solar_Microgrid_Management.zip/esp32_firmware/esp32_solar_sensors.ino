/*
 * =====================================================================================
 * Project: AI-Based Solar Microgrid Management System Using IoT & Machine Learning
 * File: esp32_solar_sensors.ino
 * Target Microcontroller: ESP32 30-Pin NodeMCU / DevKit V1 Board
 * Baud Rate: 115200 bps
 * Output Format: JSON Lines (Newline-delimited JSON)
 * 
 * SENSOR HARDWARE PIN CONNECTIONS:
 * -------------------------------------------------------------------------------------
 * 1. DHT22 (AM2302) Temperature & Relative Humidity:
 *    - Pin 1 (VCC)  --> ESP32 3.3V (or 5V if 5V-ready module with onboard regulator)
 *    - Pin 2 (DATA) --> ESP32 GPIO 4 (Add 10k pull-up resistor to 3.3V if bare sensor)
 *    - Pin 3 (NC)   --> Not connected
 *    - Pin 4 (GND)  --> ESP32 GND
 * 
 * 2. BH1750 Digital Ambient Light Intensity (I2C):
 *    - VCC          --> ESP32 3.3V
 *    - GND          --> ESP32 GND
 *    - SCL          --> ESP32 GPIO 22 (Hardware I2C Clock)
 *    - SDA          --> ESP32 GPIO 21 (Hardware I2C Data)
 *    - ADDR / ADD   --> GND (Address 0x23)
 * 
 * 3. INA219 High-Side DC Voltage, Current, Power (I2C):
 *    - VCC          --> ESP32 3.3V
 *    - GND          --> ESP32 GND
 *    - SCL          --> ESP32 GPIO 22 (Hardware I2C Clock - shared with BH1750)
 *    - SDA          --> ESP32 GPIO 21 (Hardware I2C Data - shared with BH1750)
 *    - VIN+         --> Positive Terminal of Solar Panel (high-side sensing)
 *    - VIN-         --> Positive Terminal of DC Load / Microgrid Bus
 *    - Load / Solar Negative --> Common Ground with ESP32 GND
 * 
 * POWER CALCULATION SPECIFICATION:
 * -------------------------------------------------------------------------------------
 * Power (W) = Voltage (V) * Current (A)
 * Current in Amperes = Current (mA) / 1000.0
 * Power (W) = Bus_Voltage (V) * (Current (mA) / 1000.0)
 * 
 * Difference between Calculated Power and INA219 Library-Reported Power:
 * - Calculated Power: Derived directly via floating-point multiplication of measured 
 *   Bus Voltage (V) and Current (A), guaranteeing strict mathematical consistency.
 * - Library-Reported Power (getPower_mW()): Computed by INA219 internal multiplier 
 *   register with quantization/calibration scaling truncation.
 * In this firmware, both are documented and the direct physical formula V * I is enforced.
 * 
 * NOTE ON CIRCUIT PLACEMENT:
 * The INA219 must be placed directly in the solar panel output circuit between the panel
 * and the load/battery bus. If placed in an auxiliary or downstream branch, its readings
 * represent only that branch, not the total photovoltaic generation.
 * =====================================================================================
 */

#include <Wire.h>
#include <DHT.h>
#include <BH1750.h>
#include <Adafruit_INA219.h>
#include <ArduinoJson.h>

// ---------------------- PIN DEFINITIONS ----------------------
#define DHTPIN        4        // Digital GPIO for DHT22 Data line
#define DHTTYPE       DHT22    // DHT22 (AM2302) sensor type
#define I2C_SDA       21       // ESP32 hardware I2C SDA
#define I2C_SCL       22       // ESP32 hardware I2C SCL
#define STATUS_LED    2        // Onboard ESP32 Blue LED for telemetry heartbeat

// ---------------------- SENSOR INSTANCES ---------------------
DHT dht(DHTPIN, DHTTYPE);
BH1750 lightMeter(0x23);       // Default BH1750 I2C address (0x23)
Adafruit_INA219 ina219(0x40);   // Default INA219 I2C address (0x40)

// ---------------------- TIMING CONSTANTS ---------------------
// DHT22 requires at least 2.0 seconds between successive reads to guarantee valid data.
const unsigned long SENSOR_READ_INTERVAL_MS = 2000;
unsigned long lastReadTime = 0;

// ---------------------- SENSOR STATUS FLAGS ------------------
bool dhtConnected = false;
bool bh1750Connected = false;
bool ina219Connected = false;

void setup() {
  // Initialize Serial interface for Python link
  Serial.begin(115200);
  while (!Serial && millis() < 3000) {
    // Wait for serial host connection
  }

  // Initialize Onboard Status LED
  pinMode(STATUS_LED, OUTPUT);
  digitalWrite(STATUS_LED, LOW);

  // Initialize Hardware I2C bus explicitly
  Wire.begin(I2C_SDA, I2C_SCL);

  // Initialize DHT22
  dht.begin();
  delay(100);
  float initialTemp = dht.readTemperature();
  dhtConnected = (!isnan(initialTemp) && initialTemp >= -40.0 && initialTemp <= 80.0);

  // Initialize BH1750
  if (lightMeter.begin(BH1750::CONTINUOUS_HIGH_RES_MODE)) {
    bh1750Connected = true;
  } else {
    bh1750Connected = false;
  }

  // Initialize INA219
  if (ina219.begin(&Wire)) {
    // Calibrate INA219 for 32V, 2A range (0.1 ohm shunt resistor)
    ina219.setCalibration_32V_2A();
    ina219Connected = true;
  } else {
    ina219Connected = false;
  }

  // Output structured system startup message
  StaticJsonDocument<256> initDoc;
  initDoc["event"] = "INIT";
  initDoc["firmware"] = "ESP32_SOLAR_TELEMETRY_V2";
  initDoc["dht22"] = dhtConnected ? "READY" : "NOT_DETECTED";
  initDoc["bh1750"] = bh1750Connected ? "READY" : "NOT_DETECTED";
  initDoc["ina219"] = ina219Connected ? "READY" : "NOT_DETECTED";
  initDoc["baud"] = 115200;
  initDoc["interval_ms"] = SENSOR_READ_INTERVAL_MS;

  serializeJson(initDoc, Serial);
  Serial.println();
}

void loop() {
  unsigned long currentTime = millis();

  // Non-blocking sampling interval (2000 ms)
  if (currentTime - lastReadTime >= SENSOR_READ_INTERVAL_MS) {
    lastReadTime = currentTime;

    // Visual heartbeat LED indicates active measurement transmission
    digitalWrite(STATUS_LED, HIGH);

    // ----------------- 1. READ DHT22 SENSOR -----------------
    float temperature = dht.readTemperature();
    float humidity = dht.readHumidity();
    bool dhtOk = false;

    if (!isnan(temperature) && !isnan(humidity)) {
      if (temperature >= -40.0 && temperature <= 80.0 && humidity >= 0.0 && humidity <= 100.0) {
        dhtOk = true;
        dhtConnected = true;
      }
    }

    // ----------------- 2. READ BH1750 SENSOR ----------------
    float lux = -1.0;
    bool bh1750Ok = false;

    if (bh1750Connected) {
      lux = lightMeter.readLightLevel();
      if (!isnan(lux) && lux >= 0.0 && lux <= 120000.0) {
        bh1750Ok = true;
      } else {
        // Attempt recovery re-initialization
        bh1750Connected = lightMeter.begin(BH1750::CONTINUOUS_HIGH_RES_MODE);
      }
    } else {
      bh1750Connected = lightMeter.begin(BH1750::CONTINUOUS_HIGH_RES_MODE);
    }

    // ----------------- 3. READ INA219 SENSOR ----------------
    float busVoltage_V = -1.0;
    float current_mA = 0.0;
    float power_W = 0.0;
    bool inaOk = false;

    if (ina219Connected) {
      busVoltage_V = ina219.getBusVoltage_V();
      current_mA = ina219.getCurrent_mA();

      // Check if bus voltage and current are physically realistic
      if (!isnan(busVoltage_V) && busVoltage_V >= 0.0 && busVoltage_V <= 32.0 && !isnan(current_mA)) {
        inaOk = true;
        // Clamp small zero-point reverse noise (-5mA to 0mA) to 0.0
        if (current_mA < 0.0 && current_mA >= -5.0) {
          current_mA = 0.0;
        }

        // PHYSICAL POWER CALCULATION:
        // Power (W) = Voltage (V) * Current (A) = Voltage (V) * (Current (mA) / 1000.0)
        float current_A = current_mA / 1000.0f;
        power_W = busVoltage_V * current_A;
        if (power_W < 0.0f) {
          power_W = 0.0f;
        }
      } else {
        // Attempt recovery re-initialization
        ina219Connected = ina219.begin(&Wire);
      }
    } else {
      ina219Connected = ina219.begin(&Wire);
    }

    // ----------------- CONSTRUCT JSON TELEMETRY --------------
    StaticJsonDocument<384> doc;
    doc["uptime_ms"] = currentTime;

    // Populate DHT22 fields (null if sensor offline or reading failed)
    if (dhtOk) {
      doc["temp"] = round(temperature * 10.0) / 10.0;
      doc["humidity"] = round(humidity * 10.0) / 10.0;
      doc["dht_status"] = "OK";
    } else {
      doc["temp"] = (char*)NULL;
      doc["humidity"] = (char*)NULL;
      doc["dht_status"] = "ERR";
    }

    // Populate BH1750 fields (null if sensor offline or reading failed)
    if (bh1750Ok) {
      doc["lux"] = round(lux * 10.0) / 10.0;
      doc["bh1750_status"] = "OK";
    } else {
      doc["lux"] = (char*)NULL;
      doc["bh1750_status"] = "ERR";
    }

    // Populate INA219 fields (null if sensor offline or reading failed)
    if (inaOk) {
      doc["voltage"] = round(busVoltage_V * 100.0) / 100.0;
      doc["current_ma"] = round(current_mA * 10.0) / 10.0;
      doc["power_w"] = round(power_W * 1000.0) / 1000.0;
      doc["ina219_status"] = "OK";
    } else {
      doc["voltage"] = (char*)NULL;
      doc["current_ma"] = (char*)NULL;
      doc["power_w"] = (char*)NULL;
      doc["ina219_status"] = "ERR";
    }

    // Composite status flag
    String statusStr = "";
    if (dhtOk && bh1750Ok && inaOk) {
      statusStr = "OK";
    } else {
      if (!dhtOk) statusStr += "DHT_ERR;";
      if (!bh1750Ok) statusStr += "BH1750_ERR;";
      if (!inaOk) statusStr += "INA219_ERR;";
    }
    doc["status"] = statusStr;

    // Transmit JSON Line to USB Serial (Laptop Python Link)
    serializeJson(doc, Serial);
    Serial.println();

    digitalWrite(STATUS_LED, LOW);
  }
}
