# AI-Based Solar Microgrid Management System

**A Complete Cyber-Physical IoT & Machine Learning Final-Year BE CSE Project**

[![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![ESP32](https://img.shields.io/badge/Hardware-ESP32%20DevKit-red.svg)](https://www.espressif.com/)
[![Streamlit](https://img.shields.io/badge/UI-Streamlit%201.30%2B-brightgreen.svg)](https://streamlit.io/)
[![Machine Learning](https://img.shields.io/badge/Model-Random%20Forest%20Regressor-orange.svg)](https://scikit-learn.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

---

## 1. Project Overview

The **AI-Based Solar Microgrid Management System** monitors real-time solar photovoltaic (PV) generation, logs sensor telemetry to CSV format, forecasts short-term available solar power using machine learning, and dynamically evaluates whether generation is sufficient to power connected DC loads.

### Key Capabilities:
- **Physical Sensor Fusion:** Samples ambient temperature and humidity (DHT22), surface light intensity (BH1750), and bus voltage, current, and power (INA219) via ESP32.
- **Resilient Serial Ingestion:** Streams newline-delimited JSON Lines at 115200 baud with port auto-detection, schema validation, and duplicate rejection.
- **Automated CSV Logging:** Appends validated readings to `data/solar_dataset_live.csv` without data corruption.
- **Numerical Energy Accounting:** Integrates instantaneous power ($P$) over time to calculate cumulative energy in Watt-hours ($Wh$) via the trapezoidal rule.
- **Machine Learning Forecasting:** Predicts short-term power availability via a chronologically split Random Forest Regressor ($R^2 \approx 0.99$).
- **Microgrid Decision Engine:** Compares generation against a configurable DC load demand ($1\text{--}20\text{ W}$) to classify states into `SOLAR_SUFFICIENT` or `SOLAR_INSUFFICIENT`.
- **9-View Full-Stack Dashboard:** Built with Streamlit and Plotly for streaming telemetry, interactive gauges, historical scatter matrices, and dataset exploration.
- **Physics-Grounded Simulator Mode:** Allows complete software demonstration and testing even when physical hardware is detached.

---

## 2. Directory Structure

```
Solar_Microgrid_Management/
|-- app.py                              # Streamlit 9-view real-time interactive dashboard
|-- requirements.txt                    # Python dependencies
|-- README.md                           # Master user guide & documentation
|-- .gitignore                          # Git repository ignore rules
|-- .env.example                        # Environment configuration template
|-- run_project.bat                     # One-click Windows project launcher
|-- train_model.bat                     # One-click Windows machine learning training script
|
|-- esp32_firmware/
|   |-- esp32_solar_sensors.ino         # Complete Arduino C++ sketch for ESP32
|   |-- libraries.txt                   # Arduino IDE library specifications & install commands
|   |-- wiring_guide.md                 # Detailed pinout matrix, breadboard wiring & circuit guide
|
|-- data/
|   |-- solar_dataset_sample.csv        # Realistic 24-hr synthetic demonstration dataset (1440 rows)
|   |-- solar_dataset_live.csv          # Real-time CSV logger output (dynamically generated)
|   |-- solar_dataset_historical.csv    # 7-day multi-weather archive for ML training (2016 rows)
|   |-- data_dictionary.md              # Column specifications, physical units & ranges
|   |-- .gitkeep
|
|-- src/
|   |-- __init__.py                     # Package initialization
|   |-- config.py                       # Global constants, electrical thresholds, file paths
|   |-- sensor_serial.py                # Serial communication, port discovery & simulator
|   |-- csv_logger.py                   # Thread-safe CSV append engine with deduplication
|   |-- data_processor.py               # Energy integration (Wh), cleaning, rolling metrics
|   |-- feature_engineering.py          # Cyclical time encodings, lag features & split logic
|   |-- train_model.py                  # Random Forest training with chronological split
|   |-- predict_power.py                # Inference pipeline with physical constraint enforcement
|   |-- energy_management.py            # Microgrid decision engine (load matching, storage advice)
|   |-- alerts.py                       # Anomaly detection & electrical threshold monitoring
|
|-- models/
|   |-- solar_power_rf_model.joblib     # Pre-trained baseline Random Forest model
|   |-- model_metrics.json              # Model evaluation metrics & provenance metadata
|   |-- .gitkeep
|
|-- scripts/
|   |-- generate_sample_data.py         # Physics-based diurnal solar dataset generator
|   |-- validate_dataset.py             # Rigorous data integrity & unit validator
|   |-- export_dataset.py               # Dataset filtering & export utility
|
|-- tests/
|   |-- test_csv_logger.py              # CSV file creation, locking & appending unit tests
|   |-- test_data_processor.py          # Energy integration & KPI extraction unit tests
|   |-- test_energy_management.py       # Sufficiency & recommendation logic unit tests
|   |-- test_sensor_serial.py           # Serial message parsing & simulator unit tests
|
|-- docs/
|   |-- project_overview.md             # Abstract, problem statement, objectives, scope
|   |-- system_architecture.md          # Multi-layer architecture & data pipelines
|   |-- methodology.md                  # Scientific methodology & engineering phases
|   |-- hardware_connections.md         # Circuit schematics, breadboard guide, safety checklist
|   |-- dataset_description.md          # Provenance, collection methods, schema details
|   |-- machine_learning.md             # ML regression algorithms, feature sets, validation
|   |-- testing.md                      # Test procedures, unit testing, bench test protocols
|   |-- limitations.md                  # Physical limitations, safety constraints & roadmaps
|   |-- viva_questions.md               # 30+ comprehensive Q&A for project defense/viva
|   |-- flowchart.md                    # System & process flowcharts (Mermaid)
|   |-- uml_diagrams.md                 # Use Case, DFD 0/1, Class & Sequence diagrams (Mermaid)
|
|-- outputs/
|   |-- .gitkeep
```

---

## 3. Hardware Interconnection & Sensor Wiring

| Component | Sensor Pin | ESP32 Dev Board | Voltage / Level | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| **DHT22** | VCC | 3.3V (or VIN) | 3.3V DC | Sensor power |
| **DHT22** | DATA | **GPIO 4** | 3.3V Logic | Single-wire bidirection data line |
| **DHT22** | GND | GND | 0V | Ground reference |
| **BH1750** | VCC | 3.3V | 3.3V DC | Lux IC power |
| **BH1750** | GND | GND | 0V | Ground reference |
| **BH1750** | SCL | **GPIO 22** | 3.3V I2C Clock | Hardware I2C Clock (Bus 0) |
| **BH1750** | SDA | **GPIO 21** | 3.3V I2C Data | Hardware I2C Data (Bus 0) |
| **BH1750** | ADDR | GND | 0V | Address select (`0x23`) |
| **INA219** | VCC | 3.3V | 3.3V DC | IC digital logic supply |
| **INA219** | GND | GND | 0V | Ground reference |
| **INA219** | SCL | **GPIO 22** | 3.3V I2C Clock | Hardware I2C Clock (Bus 0) |
| **INA219** | SDA | **GPIO 21** | 3.3V I2C Data | Hardware I2C Data (Bus 0) |
| **INA219** | **VIN+** | Solar Panel (+) | Up to 26V DC | High-side sensing: positive feed from solar source |
| **INA219** | **VIN-** | DC Load (+) | Up to 26V DC | High-side sensing: output to DC load |

> [!CAUTION]
> **ELECTRICAL SAFETY RULES:**
> 1. **Never connect a bare 18650 Lithium-ion cell directly to a solar panel.** Unregulated solar panels produce 18V–21V open-circuit, which causes severe thermal runaway and fire if connected to a 4.2V lithium cell without a CC/CV charge controller (e.g. TP4056 with protection).
> 2. **Never connect a solar panel or battery directly to the ESP32 3.3V pin.** The 3.3V pin cannot tolerate high voltages.
> 3. **Initially power the ESP32 strictly from the laptop USB port.**
> 4. **Common Ground:** Ensure ESP32 GND, sensor GNDs, and the negative wire of the DC load are connected together.

---

## 4. Quickstart Guide (Windows)

### Option A: One-Click Startup (Recommended)
Double-click `run_project.bat` or run in PowerShell:
```powershell
.\run_project.bat
```
This script automatically:
1. Verifies Python 3.10+ installation.
2. Creates and activates virtual environment `.venv`.
3. Installs all packages from `requirements.txt`.
4. Checks datasets and trains the baseline model if needed.
5. Launches the Streamlit dashboard in your default browser at `http://localhost:8501`.

### Option B: Manual Terminal Execution
```powershell
# 1. Navigate to project root
cd Solar_Microgrid_Management

# 2. Install dependencies
pip install -r requirements.txt

# 3. Generate baseline datasets & audit
python scripts/generate_sample_data.py
python scripts/validate_dataset.py

# 4. Train Random Forest model
python src/train_model.py

# 5. Run automated tests (15/15 should pass)
python -m pytest tests/ -v

# 6. Launch Streamlit Dashboard
streamlit run app.py
```

---

## 5. Arduino IDE Flashing Steps

1. **Install Arduino IDE:** Download from [arduino.cc](https://www.arduino.cc/en/software).
2. **Install ESP32 Board Support:**
   - In Arduino IDE, open **File -> Preferences**.
   - In *Additional Board Manager URLs*, add:
     `https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json`
   - Open **Tools -> Board -> Boards Manager**, search for `esp32` by Espressif Systems, and click **Install**.
3. **Install Required Libraries:**
   Open **Sketch -> Include Library -> Manage Libraries...** and install:
   - `DHT sensor library` by Adafruit
   - `Adafruit Unified Sensor` by Adafruit
   - `BH1750` by Christopher Laws
   - `Adafruit INA219` by Adafruit
   - `ArduinoJson` by Benoit Blanchon (Version 6.x or 7.x)
4. **Open Sketch:**
   - Open `esp32_firmware/esp32_solar_sensors.ino`.
5. **Configure Board & Port:**
   - Go to **Tools -> Board -> ESP32 Arduino** and select **ESP32 Dev Module**.
   - Go to **Tools -> Port** and select your active COM port (e.g. `COM3` or `COM4`).
   - If flashing stalls at `Connecting.......`, hold down the **BOOT** button on the ESP32 until flashing starts.
6. **Upload:** Click the **Upload** arrow button.

---

## 6. How Real Readings Become a Live CSV Dataset

```
[ Physical Photons & DC Current ]
              │
              ▼
    Sensors (DHT22, BH1750, INA219)
              │ (I2C & GPIO Signals)
              ▼
    ESP32 Microcontroller Firmware
              │ Serializes to: {"temp": 28.5, "lux": 45000, "voltage": 14.8, "power_w": 6.2, ...}\n
              ▼ (USB Serial @ 115200 Baud)
    Python SerialSensorReader (src/sensor_serial.py)
              │
              ├─► Verifies bounds (0-25V, 0-3.2A, 0-120k lx)
              ├─► Rejects corrupted packets & flags sensor errors
              ▼
    Python CSVLogger (src/csv_logger.py)
              │
              ├─► Verifies canonical column order (14 fields)
              ├─► Deduplicates timestamps (prevents UI refresh bloat)
              ▼
    Appended to disk: data/solar_dataset_live.csv
              │
              ▼
    DataProcessor (src/data_processor.py)
              │ Computes Trapezoidal Numerical Integration
              ▼
    Cumulative Energy Yield (Wh) & Streamlit UI Dashboard
```

---

## 7. Automated Test Suite

Run the full automated test suite anytime using pytest:
```powershell
python -m pytest tests/ -v
```
All 15 unit tests verify CSV locking, deduplication, numerical energy integration, Random Forest inference bounds, and microgrid decision states.

