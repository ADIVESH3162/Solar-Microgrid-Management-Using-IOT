# Solar Microgrid Dataset Data Dictionary

This document specifies the exact schema, data types, physical units, sensor sources, expected ranges, and missing-value conventions for all CSV datasets generated or consumed by the Solar Microgrid Management System:
- `data/solar_dataset_live.csv` (Genuine real-time telemetry collected exclusively from ESP32 hardware)
- `data/solar_dataset_sample.csv` (Realistic physics-based synthetic benchmark sample dataset)
- `data/solar_dataset_historical.csv` (Multi-day historical dataset for model training)

---

## 1. Live Hardware Dataset Schema (`data/solar_dataset_live.csv`)

The live dataset contains **strictly 9 canonical columns** capturing physical sensor measurements:

| Column Name | Data Type | Physical Unit | Source Sensor / Module | Expected Range | Null / Missing Representation | Description |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `timestamp` | String (ISO-8601) | Local / Host | Laptop Clock on receipt | `YYYY-MM-DD HH:MM:SS` | Not allowed | Host arrival timestamp of verified packet. |
| `temperature_c` | Float | Celsius (°C) | DHT22 (GPIO 4) | -40.0 to 80.0 °C | Empty (`""`) / `NaN` | Ambient temperature around PV setup. |
| `humidity_pct` | Float | Percentage (%) | DHT22 (GPIO 4) | 0.0 to 100.0 % | Empty (`""`) / `NaN` | Ambient relative humidity. |
| `light_lux` | Float | Lux (lx) | BH1750 (I2C 0x23) | 0.0 to 120,000.0 lx | Empty (`""`) / `NaN` | Surface sunlight illuminance. |
| `solar_voltage_v` | Float | Volts (V) | INA219 (I2C 0x40) | 0.0 to 26.0 V | Empty (`""`) / `NaN` | DC bus voltage from solar PV panel. |
| `solar_current_ma`| Float | Milliamperes (mA)| INA219 (I2C 0x40) | 0.0 to 3,200.0 mA | Empty (`""`) / `NaN` | DC current through INA219 shunt resistor. |
| `solar_power_w` | Float | Watts (W) | Calculated ($V \times I$)| 0.0 to 85.0 W | Empty (`""`) / `NaN` | Physical power: $P = V \times (I_{mA} / 1000.0)$. |
| `data_source` | String | Categorical | Provenance Engine | `esp32_hardware` | Not allowed | Strictly set to `esp32_hardware`. |
| `sensor_status` | String | Flag String | ESP32 Firmware | `OK`, `DHT_ERR`, `BH1750_ERR`, `INA219_ERR` | `UNKNOWN` | Hardware diagnostic health flags. |

---

## 2. Power Calculation Specification

$$\text{Power (Watts)} = \text{Voltage (Volts)} \times \text{Current (Amperes)}$$
$$\text{Current (Amperes)} = \frac{\text{Current (mA)}}{1000.0}$$
$$\text{Power (W)} = \text{solar\_voltage\_v} \times \left(\frac{\text{solar\_current\_ma}}{1000.0}\right)$$

### Difference from INA219 Library-Reported Power:
- **Direct Software Calculation ($V \times I$):** Uses floating-point multiplication of bus voltage and current, ensuring mathematical exactness across all dashboards, charts, and CSV logs.
- **Library Register (`getPower_mW()`):** Uses the INA219 internal multiplier register with fixed-point truncation and calibration divisor rounding.
- **Sensor Placement Requirement:** The INA219 sensor must be wired directly on the solar panel output line (`VIN+` to panel (+), `VIN-` to DC load/bus (+)) with common ground to measure total solar generation.

---

## 3. Provenance and Integrity Rules
1. **Never Mix Demo Data into Live Dataset:** The live CSV logger strictly blocks synthetic/demo records.
2. **No Artificial Zeroes for Missing Values:** If a sensor is disconnected or reading fails, the field is recorded as null (empty string), NOT 0.0, to prevent false readings.
3. **No Duplicate Rows:** Exact duplicate timestamps from UI reruns are rejected.
4. **Preserve Existing Records:** Existing genuine records are never overwritten when restarting the application.
