"""
Dataset Validation and Integrity Audit Tool
Rigorously inspects CSV datasets for schema compliance, timestamp monotonicity,
physical electrical consistency (Ohm's / Watt's laws), missing values, and anomaly rates.
"""

import sys
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import numpy as np
import pandas as pd

from src.config import (
    CSV_COLUMNS,
    DATA_DIR,
    HISTORICAL_CSV_PATH,
    LIVE_CSV_PATH,
    SAMPLE_CSV_PATH,
)


def validate_single_csv(filepath: Path) -> dict:
    """
    Audit an individual solar dataset file.
    Returns dictionary with validation results.
    """
    report = {
        "file": filepath.name,
        "exists": filepath.exists(),
        "passed": True,
        "errors": [],
        "warnings": [],
        "total_rows": 0,
        "null_counts": {},
    }

    if not filepath.exists():
        report["passed"] = False
        report["errors"].append("File does not exist.")
        return report

    try:
        df = pd.read_csv(filepath)
    except Exception as ex:
        report["passed"] = False
        report["errors"].append(f"Failed to read CSV: {ex}")
        return report

    report["total_rows"] = len(df)
    if len(df) == 0:
        report["warnings"].append("Dataset is empty (0 records).")
        return report

    # 1. Schema check
    missing_cols = [c for c in CSV_COLUMNS if c not in df.columns]
    if missing_cols:
        report["passed"] = False
        report["errors"].append(f"Missing canonical columns: {missing_cols}")

    # 2. Timestamp validation
    if "timestamp" in df.columns:
        parsed_ts = pd.to_datetime(df["timestamp"], errors="coerce")
        bad_ts_count = parsed_ts.isna().sum()
        if bad_ts_count > 0:
            report["passed"] = False
            report["errors"].append(f"{bad_ts_count} rows have invalid or unparseable timestamps.")
        else:
            # Monotonicity check
            if not parsed_ts.is_monotonic_increasing:
                report["warnings"].append("Timestamps are not strictly non-decreasing.")

    # 3. Duplicate checks
    dup_ts = df["timestamp"].duplicated().sum()
    if dup_ts > 0:
        report["warnings"].append(f"{dup_ts} duplicate timestamps found.")

    # 4. Physical bounds validation
    # Voltage check
    if "solar_voltage_v" in df.columns:
        v = pd.to_numeric(df["solar_voltage_v"], errors="coerce").dropna()
        if (v < 0).any() or (v > 30.0).any():
            report["passed"] = False
            report["errors"].append(f"Voltage out of range [0, 30V]: min={v.min()}, max={v.max()}")

    # Current check
    if "solar_current_ma" in df.columns:
        i = pd.to_numeric(df["solar_current_ma"], errors="coerce").dropna()
        if (i < 0).any() or (i > 3500.0).any():
            report["passed"] = False
            report["errors"].append(f"Current out of range [0, 3500mA]: min={i.min()}, max={i.max()}")

    # Power check
    if "solar_power_w" in df.columns:
        p = pd.to_numeric(df["solar_power_w"], errors="coerce").dropna()
        if (p < 0).any() or (p > 100.0).any():
            report["passed"] = False
            report["errors"].append(f"Power out of range [0, 100W]: min={p.min()}, max={p.max()}")

    # Electrical consistency (P ~= V * I / 1000)
    if "solar_voltage_v" in df.columns and "solar_current_ma" in df.columns and "solar_power_w" in df.columns:
        sub = df[["solar_voltage_v", "solar_current_ma", "solar_power_w"]].dropna()
        if not sub.empty:
            expected_p = (sub["solar_voltage_v"] * sub["solar_current_ma"]) / 1000.0
            discrepancy = (sub["solar_power_w"] - expected_p).abs()
            if (discrepancy > 0.5).sum() > len(sub) * 0.05:
                report["warnings"].append(
                    "Over 5% of records have electrical power discrepancy between P and V*I."
                )

    # 5. Null count summary
    report["null_counts"] = {col: int(df[col].isna().sum()) for col in df.columns}

    return report


def main():
    target_files = [SAMPLE_CSV_PATH, HISTORICAL_CSV_PATH]
    if LIVE_CSV_PATH.exists():
        target_files.append(LIVE_CSV_PATH)

    print("\n" + "=" * 65)
    print("         SOLAR DATASET VALIDATION & INTEGRITY AUDIT")
    print("=" * 65)

    all_passed = True
    for f in target_files:
        res = validate_single_csv(f)
        status_label = "[PASSED]" if res["passed"] else "[FAILED]"
        print(f"\n{status_label} {res['file']} (Rows: {res['total_rows']})")
        if res["errors"]:
            all_passed = False
            print("  ERRORS:")
            for err in res["errors"]:
                print(f"    - {err}")
        if res["warnings"]:
            print("  WARNINGS:")
            for w in res["warnings"]:
                print(f"    * {w}")
        if not res["errors"] and not res["warnings"]:
            print("  * Schema valid, physics constraints verified, zero critical defects.")

    print("\n" + "=" * 65)
    print(f"OVERALL AUDIT STATUS: {'ALL CHECKS PASSED' if all_passed else 'SOME CHECKS FAILED'}")
    print("=" * 65 + "\n")

    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())

