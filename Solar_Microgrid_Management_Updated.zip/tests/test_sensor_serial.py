"""
Unit tests for Sensor Serial and Simulator Module
Verifies JSON telemetry validation, corrupted packet drop, bounds checking,
and simulator physics generation.
"""

import sys
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import pytest

from src.sensor_serial import SerialSensorReader, SimulatorSensorReader


def test_serial_sanitization_valid():
    """Verify clean JSON record from ESP32 is correctly parsed into standard dictionary."""
    reader = SerialSensorReader()
    raw_packet = {
        "uptime_ms": 12500,
        "temp": 29.4,
        "humidity": 52.1,
        "lux": 51200.0,
        "voltage": 14.85,
        "current_ma": 510.2,
        "power_w": 7.576,
        "status": "OK",
    }

    sanitized = reader._validate_and_sanitize(raw_packet)
    assert sanitized["temperature_c"] == 29.4
    assert sanitized["humidity_pct"] == 52.1
    assert sanitized["light_lux"] == 51200.0
    assert sanitized["solar_voltage_v"] == 14.85
    assert sanitized["solar_current_ma"] == 510.2
    assert sanitized["solar_power_w"] == pytest.approx(7.576)
    assert sanitized["data_source"] == "esp32_hardware"
    assert sanitized["sensor_status"] == "OK"


def test_serial_sanitization_out_of_bounds():
    """Verify physical bound violations (e.g., negative lux, impossible temp) are converted to None."""
    reader = SerialSensorReader()
    raw_packet = {
        "temp": 150.0,      # Exceeds max 65°C safe limit
        "humidity": -10.0,  # Negative humidity impossible
        "lux": -50.0,       # Negative lux impossible
        "voltage": 50.0,    # Exceeds max 25V bench limit
        "status": "DHT_ERR",
    }

    sanitized = reader._validate_and_sanitize(raw_packet)
    assert sanitized["temperature_c"] is None
    assert sanitized["humidity_pct"] is None
    assert sanitized["light_lux"] is None
    assert sanitized["solar_voltage_v"] is None
    assert sanitized["sensor_status"] == "DHT_ERR"


def test_simulator_sensor_reader():
    """Verify simulator generates physics-compliant records tagged as SIMULATED_DEMO."""
    sim = SimulatorSensorReader(rated_watts=10.0)
    reading = sim.read_reading()

    assert reading["data_source"] == "SIMULATED_DEMO"
    assert reading["sensor_status"] == "SIMULATED"
    assert "timestamp" in reading
    assert reading["temperature_c"] is not None
    assert reading["light_lux"] is not None
    assert reading["solar_voltage_v"] >= 0.0
    assert reading["solar_power_w"] >= 0.0

