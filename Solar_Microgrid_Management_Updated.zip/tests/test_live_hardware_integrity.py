"""
Unit tests for Real-Time Live Hardware Integrity
Verifies:
1. Rejection of synthetic/demo data from the live CSV dataset.
2. Acceptance and strict formatting of genuine 'esp32_hardware' readings.
3. Strict 9-column live schema conformance.
4. Prevention of duplicate rows on repeated UI refreshes.
5. Preservation of existing historical CSV records upon reboot/initialization.
6. Mathematical correctness of Power (W) = Voltage (V) * Current (A).
7. Disconnected hardware generates zero rows and returns None.
"""

import sys
import tempfile
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import pandas as pd
import pytest

from src.config import DATA_SOURCE_HARDWARE, LIVE_CSV_COLUMNS, LIVE_CSV_PATH
from src.csv_logger import CSVLogger
from src.sensor_serial import SerialSensorReader, SimulatorSensorReader


@pytest.fixture
def temp_live_csv():
    with tempfile.TemporaryDirectory() as tmpdir:
        path = Path(tmpdir) / "solar_dataset_live.csv"
        yield path


def test_live_csv_canonical_9_columns(temp_live_csv):
    """Verify live dataset schema has exactly the 9 required canonical columns in correct order."""
    logger = CSVLogger(target_filepath=temp_live_csv, columns=LIVE_CSV_COLUMNS)
    assert temp_live_csv.exists()

    df = pd.read_csv(temp_live_csv)
    assert list(df.columns) == [
        "timestamp",
        "temperature_c",
        "humidity_pct",
        "light_lux",
        "solar_voltage_v",
        "solar_current_ma",
        "solar_power_w",
        "data_source",
        "sensor_status",
    ]


def test_live_csv_rejects_synthetic_data():
    """Verify live CSV logger rejects synthetic/demo data source tags."""
    # Test on LIVE_CSV_PATH target
    logger = CSVLogger(target_filepath=LIVE_CSV_PATH)
    fake_reading = {
        "timestamp": "2026-10-12 12:00:00",
        "temperature_c": 28.5,
        "humidity_pct": 55.0,
        "light_lux": 50000.0,
        "solar_voltage_v": 14.5,
        "solar_current_ma": 450.0,
        "solar_power_w": 6.525,
        "data_source": "SIMULATED_DEMO",
        "sensor_status": "SIMULATED",
    }
    # Must be explicitly rejected
    assert logger.append_reading(fake_reading) is False


def test_live_csv_accepts_esp32_hardware(temp_live_csv):
    """Verify genuine esp32_hardware records are correctly written and formatted."""
    logger = CSVLogger(target_filepath=temp_live_csv, columns=LIVE_CSV_COLUMNS)
    valid_reading = {
        "timestamp": "2026-10-12 12:00:01",
        "temperature_c": 29.1,
        "humidity_pct": 52.0,
        "light_lux": 48200.0,
        "solar_voltage_v": 14.80,
        "solar_current_ma": 420.5,
        "solar_power_w": 6.223,
        "data_source": DATA_SOURCE_HARDWARE,
        "sensor_status": "OK",
    }
    assert logger.append_reading(valid_reading) is True
    assert logger.get_record_count() == 1

    df = logger.load_dataframe()
    assert len(df) == 1
    assert df.iloc[0]["data_source"] == "esp32_hardware"
    assert df.iloc[0]["solar_power_w"] == pytest.approx(6.223)


def test_disconnected_hardware_does_not_generate_live_rows():
    """Verify disconnected reader produces no readings and appends no live rows."""
    reader = SerialSensorReader()
    assert reader.is_connected is False
    assert reader.read_reading() is None
    assert reader.get_latest_reading() is None


def test_repeated_dashboard_refreshes_prevent_duplicates(temp_live_csv):
    """Verify exact duplicate timestamps from UI refresh are ignored."""
    logger = CSVLogger(target_filepath=temp_live_csv, columns=LIVE_CSV_COLUMNS)
    reading = {
        "timestamp": "2026-10-12 12:00:05",
        "temperature_c": 28.0,
        "humidity_pct": 50.0,
        "light_lux": 40000.0,
        "solar_voltage_v": 14.0,
        "solar_current_ma": 400.0,
        "solar_power_w": 5.60,
        "data_source": DATA_SOURCE_HARDWARE,
        "sensor_status": "OK",
    }
    assert logger.append_reading(reading) is True
    # Attempting to log the same reading on subsequent refreshes must return False
    assert logger.append_reading(reading) is False
    assert logger.append_reading(reading) is False
    assert logger.get_record_count() == 1


def test_existing_csv_records_preserved(temp_live_csv):
    """Verify that existing records are preserved when CSVLogger is re-initialized."""
    logger1 = CSVLogger(target_filepath=temp_live_csv, columns=LIVE_CSV_COLUMNS)
    r1 = {
        "timestamp": "2026-10-12 12:00:10",
        "temperature_c": 27.5,
        "humidity_pct": 55.0,
        "light_lux": 42000.0,
        "solar_voltage_v": 13.5,
        "solar_current_ma": 380.0,
        "solar_power_w": 5.13,
        "data_source": DATA_SOURCE_HARDWARE,
        "sensor_status": "OK",
    }
    assert logger1.append_reading(r1) is True

    # Simulate app reboot by creating a new logger instance on the same file
    logger2 = CSVLogger(target_filepath=temp_live_csv, columns=LIVE_CSV_COLUMNS)
    assert logger2.get_record_count() == 1
    assert logger2.last_logged_timestamp == "2026-10-12 12:00:10"

    # Appending a new second reading
    r2 = {
        "timestamp": "2026-10-12 12:00:12",
        "temperature_c": 27.6,
        "humidity_pct": 54.8,
        "light_lux": 42100.0,
        "solar_voltage_v": 13.6,
        "solar_current_ma": 385.0,
        "solar_power_w": 5.236,
        "data_source": DATA_SOURCE_HARDWARE,
        "sensor_status": "OK",
    }
    assert logger2.append_reading(r2) is True
    assert logger2.get_record_count() == 2


def test_power_calculation_v_times_i():
    """Verify Power (W) is calculated as Voltage (V) * Current (A) = V * (current_mA / 1000.0)."""
    reader = SerialSensorReader()
    # 15.0 V and 600.0 mA -> Current = 0.60 A -> Power = 15.0 * 0.60 = 9.0 W
    packet = {
        "temp": 30.0,
        "humidity": 45.0,
        "lux": 60000.0,
        "voltage": 15.0,
        "current_ma": 600.0,
        "status": "OK",
    }
    res = reader._validate_and_sanitize(packet)
    assert res["solar_power_w"] == pytest.approx(9.0)

    # Missing voltage or current must result in power_w = None (N/A), not 0.0
    packet_missing = {
        "temp": 30.0,
        "humidity": 45.0,
        "lux": 60000.0,
        "voltage": None,
        "current_ma": None,
        "status": "INA219_ERR",
    }
    res_missing = reader._validate_and_sanitize(packet_missing)
    assert res_missing["solar_power_w"] is None
    assert res_missing["solar_voltage_v"] is None
    assert res_missing["solar_current_ma"] is None
